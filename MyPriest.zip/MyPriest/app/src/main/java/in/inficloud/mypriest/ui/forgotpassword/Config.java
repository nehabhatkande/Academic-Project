package in.inficloud.mypriest.ui.forgotpassword;

public class Config {

       //public static final String EMAIL ="priest@inficloud.in";
     // public static final String PASSWORD ="bond007";
       //public static final String EMAIL ="meghabhekane41@gmail.com";
      //public static final String PASSWORD ="Me$h@123";
       public static final String EMAIL ="shrutibastwad@gmail.com";
    public static final String PASSWORD ="516516516";
}
