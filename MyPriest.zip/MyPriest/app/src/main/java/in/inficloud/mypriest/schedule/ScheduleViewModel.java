package in.inficloud.mypriest.schedule;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

import in.inficloud.mypriest.schedule.Schedule;
import in.inficloud.mypriest.schedule.ScheduleRepository;

public class ScheduleViewModel extends AndroidViewModel {

    private ScheduleRepository repository;
    private LiveData<List<Schedule>> allSchedules;
    private List<Schedule> mySchedules;

    public ScheduleViewModel(@NonNull Application application) {
        super(application);
        repository = new ScheduleRepository(application);
        allSchedules = repository.getAllSchedule();

     }

     public void insert(Schedule schedule){
        repository.insert(schedule);
     }

     public void update(Schedule schedule){
        repository.update(schedule);
     }

    public void delete(Schedule schedule){
        repository.delete(schedule);
    }

    public void deleteAllSchedules(){
        repository.deleteAllSchedules();
    }

    public LiveData<List<Schedule>> getAllSchedules(){
        return allSchedules;
    }

    public List<Schedule> getMySchedules(String mobile) {
        mySchedules=repository.getSchedules(mobile);
        return mySchedules;
    };

    public List<Schedule> getMySchedulesForDay(String mobile,String date) {
        mySchedules=repository.getSchedulesForDay(mobile,date);
        return mySchedules;
    };
}
