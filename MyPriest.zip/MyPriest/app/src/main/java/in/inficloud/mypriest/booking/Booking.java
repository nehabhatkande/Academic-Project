package in.inficloud.mypriest.booking;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "priest_bookings")
public class Booking {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private String name;
    private String date;
    private String time;
    private String priest;
    private String user;
    private String religion;
    private String status;

    public Booking(String name, String date, String time, String priest, String user, String religion, String status) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.priest = priest;
        this.user = user;
        this.religion = religion;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getPriest() {
        return priest;
    }

    public String getReligion() {
        return religion;
    }

    public String getStatus() {
        return status;
    }

    public int getId() {
        return id;
    }

    public String getUser() {
        return user;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setPriest(String priest) {
        this.priest = priest;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

