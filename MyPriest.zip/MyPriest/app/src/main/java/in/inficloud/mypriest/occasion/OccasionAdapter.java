package in.inficloud.mypriest.occasion;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import in.inficloud.mypriest.R;

public class OccasionAdapter extends ListAdapter<Occasion, OccasionAdapter.OccasionHolder> {


    private OnItemClickListener listener;

    public OccasionAdapter() {
        super(DIFF_CALLBACK);
    }

    private static final DiffUtil.ItemCallback<Occasion> DIFF_CALLBACK =  new DiffUtil.ItemCallback<Occasion>() {
        @Override
        public boolean areItemsTheSame(@NonNull Occasion oldItem, @NonNull Occasion newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Occasion oldItem, @NonNull Occasion newItem) {
            return oldItem.getName().equals(newItem.getName()) &&
                    oldItem.getReligion().equals(newItem.getReligion()) &&
                    oldItem.getDescripton().equals(newItem.getDescripton());
        }
    };

    @NonNull
    @Override
    public OccasionHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.occasion_item, parent, false);
        return new OccasionHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull OccasionHolder holder, int position) {

        Occasion currentOccasion = getItem(position);
        holder.textViewname.setText(currentOccasion.getName());
        holder.textViewReligion.setText(currentOccasion.getReligion());
        holder.textViewDescription.setText(String.valueOf(currentOccasion.getDescripton()));
    }


    public Occasion getOccasionAt(int position) {
        return getItem(position);
    }

    class OccasionHolder extends RecyclerView.ViewHolder {
        private TextView textViewname;
        private TextView textViewDescription;
        private TextView textViewReligion;


        public OccasionHolder(@NonNull View itemView) {
            super(itemView);
            textViewname = itemView.findViewById(R.id.name);
            textViewDescription = itemView.findViewById(R.id.description);
            textViewReligion = itemView.findViewById(R.id.religion);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (listener != null && position!= RecyclerView.NO_POSITION) {
                        listener.onItemClick(getItem(position));
                    }
                }
            });

        }
    }

    public interface OnItemClickListener {
        void onItemClick(Occasion note);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
