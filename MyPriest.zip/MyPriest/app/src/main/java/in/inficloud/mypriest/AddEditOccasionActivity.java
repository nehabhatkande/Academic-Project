package in.inficloud.mypriest;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.CaseMap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;
import com.jaredrummler.materialspinner.MaterialSpinner;

public class AddEditOccasionActivity extends AppCompatActivity {


    public static final String EXTRA_ID =
            "com.example.architectureexample.EXTRA_ID";

    public static final String EXTRA_NAME =
            "com.example.architectureexample.EXTRA_NAME";

    public static final String EXTRA_PRICE =
            "com.example.architectureexample.EXTRA_PRICE";
    //public static final String EXTRA_DATE =
            //"com.example.architectureexample.EXTRA_DATE";
    public static final String EXTRA_RELIGION =
            "com.example.architectureexample.EXTRA_RELIGION";
    public static final String EXTRA_DESCRIPTION =
            "com.example.architectureexample.EXTRA_DESCRIPTION";


    private EditText editTextName;
    //private EditText editTextDate;
    private EditText editTextDescription;
    //private NumberPicker numberPickerReligion;
    private String sReligion;
    private EditText editTextPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_occasion);

        editTextName = findViewById(R.id.edit_text_name);
        editTextPrice = findViewById(R.id.edit_text_price);
        //editTextDate = findViewById(R.id.edit_text_date);
        editTextDescription = findViewById(R.id.edit_text_description);
       // numberPickerReligion = findViewById(R.id.number_picker_religion);

        //numberPickerReligion.setMaxValue(1);
        //numberPickerReligion.setMaxValue(4);

        final MaterialSpinner spinner = findViewById(R.id.religionAdd);
        spinner.setItems("Select Religion", "Hindu", "Muslim", "Christian", "Sikh");

        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {

            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                Snackbar.make(view, "Clicked " + item, Snackbar.LENGTH_LONG).show();
                sReligion = item;
            }


        });




        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);

        Intent intent = getIntent();

        if (intent.hasExtra(EXTRA_ID)) {
            setTitle("Edit Occasion");
            editTextName.setText(intent.getStringExtra(EXTRA_NAME));
            //editTextDate.setText(intent.getStringExtra(EXTRA_DATE));
            editTextDescription.setText(intent.getStringExtra(EXTRA_DESCRIPTION));

         //   numberPickerReligion.setValue(intent.getIntExtra(EXTRA_RELIGION, 1));
        }else {
            setTitle("Add Occasion");
        }



    }


    private void saveOccasion() {
        String name = editTextName.getText().toString();
        String price = editTextPrice.getText().toString();
        //String date = editTextDate.getText().toString();
        String descrption = editTextDescription.getText().toString();
        //String religion = numberPickerReligion.getText.toS();

        if (name.trim().isEmpty() || descrption.trim().isEmpty()) {
            Toast.makeText(this, "Please insert a name and description", Toast.LENGTH_SHORT).show();
            return;
        }

        Intent data = new Intent();
        data.putExtra(EXTRA_NAME, name);
        //data.putExtra(EXTRA_DATE, date);
        data.putExtra(EXTRA_PRICE, price);
        data.putExtra(EXTRA_DESCRIPTION, descrption);

        data.putExtra(EXTRA_RELIGION, sReligion);

        int id  = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id != -1){
            data.putExtra(EXTRA_ID,id);
        }

        setResult(RESULT_OK, data);
        finish();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_occasion_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_occasion:
                saveOccasion();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
