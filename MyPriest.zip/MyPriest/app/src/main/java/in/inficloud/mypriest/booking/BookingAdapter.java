package in.inficloud.mypriest.booking;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import in.inficloud.mypriest.CustomMarkerClusteringDemoActivity;
import in.inficloud.mypriest.PriestActivity;
import in.inficloud.mypriest.R;
import in.inficloud.mypriest.UserActivity;
import in.inficloud.mypriest.booking.Booking;
import in.inficloud.mypriest.schedule.ScheduleViewModel;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserRepository;
import in.inficloud.mypriest.user.UserViewModel;

import static android.content.ContentValues.TAG;

public class BookingAdapter extends ListAdapter<Booking, BookingAdapter.BookingHolder> {


    private OnItemClickListener listener;

    public BookingAdapter() {
        super(DIFF_CALLBACK);
    }

    private UserViewModel userViewModel;

    private Context context;
    List<String> scheduleSpinnerList = new ArrayList<>();




    private static final DiffUtil.ItemCallback<Booking> DIFF_CALLBACK =  new DiffUtil.ItemCallback<Booking>() {
        @Override
        public boolean areItemsTheSame(@NonNull Booking oldItem, @NonNull Booking newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Booking oldItem, @NonNull Booking newItem) {
            return oldItem.getName().equals(newItem.getName()) &&
                    oldItem.getReligion().equals(newItem.getReligion()) &&
                    oldItem.getDate().equals(newItem.getDate());

        }
    };



    @NonNull
    @Override
    public BookingHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        context = parent.getContext();

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_booking, parent, false);
        return new BookingHolder(itemView);
    }




    @Override
    public void onBindViewHolder(@NonNull BookingHolder holder, int position) {

        scheduleSpinnerList = new ArrayList<>(Arrays.asList("12AM-2AM", "2AM-4AM", "4AM-6AM", "6AM-8AM", "8AM-10AM", "10AM-12PM", "12PM-2PM", "2PM-4PM", "4PM-6PM", "6PM-8PM", "8PM-10PM", "10PM-12PM"
        ));

        Booking currentBooking = getItem(position);
        holder.textViewname.setText( "  "+currentBooking.getName());
       // holder.textViewReligion.setText(currentBooking.getReligion());
        holder.textViewDate.setText("  "+String.valueOf( currentBooking.getDate()));
        String time= currentBooking.getTime();
        String [] parts = time.split(":");
        holder.textViewTime.setText(String.valueOf( scheduleSpinnerList.get(Integer.parseInt(parts[0]))));
        //holder.textViewTime.setText(String.valueOf( currentBooking.getTime()+"  "));
        Log.d(TAG, "onBindViewHolder: "+currentBooking.getTime());
       // holder.textViewPriest.setText(String.valueOf("Priest: "+ currentBooking.getPriest()));
        Log.d(TAG, "onBindViewHolder: "+String.valueOf( currentBooking.getUser()));

        //holder.textViewPriest.setText("  "+String.valueOf(currentBooking.getPriest()));
        if(context instanceof PriestActivity){
            holder.textViewUser.setText("  "+String.valueOf( currentBooking.getUser()));
        }
        else if(context instanceof UserActivity){
            holder.textViewUser.setText("  "+String.valueOf( currentBooking.getPriest()));
        }
        else{
            Log.d(TAG, "onBindViewHolder: context is not priest or user");
        }

        String usermobile = String.valueOf( currentBooking.getUser());
        userViewModel= ViewModelProviders.of((FragmentActivity) context).get(UserViewModel.class);
        List<User> users = userViewModel.getUser(usermobile);
        Log.d(TAG, "onBindViewHolder: "+users);
        Log.d(TAG, "onBindViewHolder: "+usermobile);
        Double lat = users.get(0).getLatitude();
        Double lang = users.get(0).getLongitude();

        Geocoder geocoder;
        List<Address> addresses = null;
        geocoder = new Geocoder(this.context);

        Log.d(TAG, "onBindViewHolder: "+lat);
        Log.d(TAG, "onBindViewHolder: "+lang);

        try {
            if (lat != null && lang != null)
            addresses = geocoder.getFromLocation(lat, lang, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (lat != null && lang != null) {
            String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
            String city = addresses.get(0).getLocality();
            String state = addresses.get(0).getAdminArea();
            String country = addresses.get(0).getCountryName();
            String postalCode = addresses.get(0).getPostalCode();
            holder.textViewLocation.setText("  "+String.valueOf(address));
            holder.textViewLocation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d(TAG, "onClick: "+address);
                    Intent intent = new Intent(context, CustomMarkerClusteringDemoActivity.class);
                    intent.putExtra("zoomlat",lat);
                    intent.putExtra("zoomlan",lang);


                   context.startActivity(intent);

                }
            });
        }
        holder.textViewStatus.setText(String.valueOf(currentBooking.getStatus()));



    }




    public Booking getBookingAt(int position) {
        return getItem(position);
    }

    class BookingHolder extends RecyclerView.ViewHolder {
        private TextView textViewname;
        private TextView textViewDate;
        private TextView textViewTime;
        private TextView textViewUser;
        //private TextView textViewPriest;
        private TextView textViewLocation;
        private TextView textViewStatus;


        public BookingHolder(@NonNull View itemView) {
            super(itemView);
            textViewname = itemView.findViewById(R.id.name);
            textViewDate = itemView.findViewById(R.id.date);
            textViewTime = itemView.findViewById(R.id.time);
            textViewUser = itemView.findViewById(R.id.user);
            //textViewPriest = itemView.findViewById(R.id.priest);
            textViewLocation = itemView.findViewById(R.id.location);
            textViewStatus = itemView.findViewById(R.id.status);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    if (listener != null && position!= RecyclerView.NO_POSITION) {
                        listener.onItemClick(getItem(position));
                    }
                }
            });

        }
    }


    public interface OnItemClickListener {
        void onItemClick(Booking booking);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
