package in.inficloud.mypriest.occasion;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "priest_occasions")
public class Occasion {


    @PrimaryKey(autoGenerate = true)
    private int id;

    private String name;
    //private String date;
    private String religion;
    private String descripton;
    private int price;


    public Occasion(String name, String religion, String descripton,int price) {
        this.name = name;
        //this.date = date;
        this.religion = religion;
        this.descripton = descripton;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    //public String getDate() {
        //return date;
    //}

    public String getReligion() {
        return religion;
    }

    public String getDescripton() {
        return descripton;
    }

    public int getPrice() {return price;}

    public void setName(String name) {
        this.name = name;
    }

    //public void setDate(String date) {
       // this.date = date;
    //}

    public void setReligion(String religion) {
        this.religion = religion;
    }


    public void setDescripton(String descripton) {
        this.descripton = descripton;
    }

    public void setPrice(int price) {this.price = price;}

    public void setId(int id) {
        this.id = id;
    }
}
