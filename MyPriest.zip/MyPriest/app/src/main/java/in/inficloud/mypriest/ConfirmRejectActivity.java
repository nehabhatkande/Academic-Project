package in.inficloud.mypriest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.ViewModelProviders;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import in.inficloud.mypriest.booking.Booking;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserViewModel;

import static in.inficloud.mypriest.AddEditBookingActivity.EXTRA_PRIEST;

public class ConfirmRejectActivity extends AppCompatActivity {

    public static final String EXTRA_ID =
            "com.example.architectureexample.EXTRA_ID";
    public static final String EXTRA_STATUS =
            "com.example.architectureexample.EXTRA_STATUS";
    private static final String TAG = "CONFIRM";

    private String date;
    private String sOccasion;
    private String sPriest;

    private UserViewModel userviewmodel;
    private Context context;
    List<String> scheduleSpinnerList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle b = getIntent().getExtras();

        scheduleSpinnerList = new ArrayList<>(Arrays.asList("12AM-2AM", "2AM-4AM", "4AM-6AM", "6AM-8AM", "8AM-10AM", "10AM-12PM", "12PM-2PM", "2PM-4PM", "4PM-6PM", "6PM-8PM", "8PM-10PM", "10PM-12PM"
        ));


        String oname = b.getString("name");
        String user = b.getString("user");
        String fname = b.getString("fname");
        String lname = b.getString("lname");
        String location = b.getString("location");
        //String [] locations = location.split(":");
        String  address = " ";
        //String city = locations[1];
        //String state = locations[2];
       // String country = locations[3];
        //String postalCode = locations[4];

        String date = b.getString("date");
        String time = b.getString("time");
        String [] parts = time.split(":");

        String reliigon = b.getString("religion");

        setContentView(R.layout.activity_confirm_reject);
        TextView textViewoname = (TextView)findViewById(R.id.c_name);
        TextView textViewName = (TextView)findViewById(R.id.c_fname) ;
        TextView textViewUser = (TextView)findViewById(R.id.c_user);
        TextView textViewLocation = (TextView)findViewById(R.id.c_location);
        //TextView textViewCity = (TextView)findViewById(R.id.c_city);
       // TextView textViewState = (TextView)findViewById(R.id.c_state);
        //TextView textViewCountry = (TextView)findViewById(R.id.c_country);
        //TextView textViewPostalCode = (TextView)findViewById(R.id.c_postalcode);
        TextView textViewDate = (TextView)findViewById(R.id.c_date);
        TextView textViewTime = (TextView)findViewById(R.id.c_time);
        TextView textViewReligion = (TextView)findViewById(R.id.c_religion);

        Log.d(TAG, "onCreate: "+oname);



        textViewoname.setText("  "+oname);
        textViewName.setText("  "+fname + " "+lname);
        textViewUser.setText("  "+user);
        textViewLocation.setText("  "+location);
       // textViewCity.setText(city);
        //textViewState.setText(state);
       // textViewCountry.setText(country);
        //textViewPostalCode.setText(postalCode);
        textViewDate.setText("  "+date);
        textViewTime.setText("  "+scheduleSpinnerList.get(Integer.parseInt(parts[0])));
        textViewReligion.setText("       "+reliigon);

        Button btnConfirm = findViewById(R.id.confirm);
        Button btnReject = findViewById(R.id.reject);

        Intent data = new Intent();

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent data = new Intent();

                data.putExtra(EXTRA_STATUS, "confirm");

                int id  = getIntent().getIntExtra(EXTRA_ID, -1);
                if (id != -1){
                    Log.d(TAG, "onClick: "+id);
                    data.putExtra(EXTRA_ID,id);
                }
                setResult(RESULT_OK,data);
                finish();

            }
        });

        btnReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent data = new Intent();
                data.putExtra(EXTRA_STATUS, "reject");
                int id  = getIntent().getIntExtra(EXTRA_ID, -1);
                if (id != -1){
                    Log.d(TAG, "onClick: "+id);
                    data.putExtra(EXTRA_ID,id);
                }
                setResult(RESULT_OK,data);
                finish();
            }
        });
    }
}
