package in.inficloud.mypriest.booking;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

import in.inficloud.mypriest.Database;
import in.inficloud.mypriest.booking.Booking;

public class BookingRepository {
    private BookingDao bookingDao;
    private LiveData<List<Booking>> allBookings;

    public BookingRepository(Application application) {
        Database database = Database.getInstance(application);
        bookingDao = database.bookingDao();
        allBookings = bookingDao.getAllBookings();

    }
    public List<Booking> getBookings(String mobile) {
        return bookingDao.getBookings(mobile);
    }

    public LiveData<List<Booking>> getAllBookingsMobile(String mobile) {
        return bookingDao.getAllBookingsMobile(mobile);
    }

    public LiveData<List<Booking>> getPriestBookingsMobile(String mobile) {
        return bookingDao.getPriestBookingsMobile(mobile);
    }


    public void insert(Booking booking){
        new InsertBookingAsyncTask(bookingDao).execute(booking);

    }

    public void update(Booking booking){
        new UpdateBookingAsyncTask(bookingDao).execute(booking);

    }

    public void delete(Booking booking){
        new DeleteBookingAsyncTask(bookingDao).execute(booking);

    }

    public void deleteAllBookings(){
        new DeleteAllBookingsAsyncTask(bookingDao).execute();

    }
    public LiveData<List<Booking>> getAllBooking(){

        return allBookings;
    }

    private static class InsertBookingAsyncTask extends AsyncTask<Booking, Void, Void> {
        private BookingDao bookingDao;

        private InsertBookingAsyncTask(BookingDao bookingDao){
            this.bookingDao = bookingDao;
        }

        @Override
        protected Void doInBackground(Booking... bookings){
            bookingDao.insert(bookings[0]);
            return null;
        }
    }

    private static class UpdateBookingAsyncTask extends AsyncTask<Booking, Void, Void> {
        private BookingDao bookingDao;

        private UpdateBookingAsyncTask(BookingDao bookingDao){
            this.bookingDao = bookingDao;
        }

        @Override
        protected Void doInBackground(Booking... bookings){
            bookingDao.update(bookings[0]);
            return null;
        }
    }

    private static class DeleteBookingAsyncTask extends AsyncTask<Booking, Void, Void> {
        private BookingDao bookingDao;

        private DeleteBookingAsyncTask(BookingDao bookingDao){
            this.bookingDao = bookingDao;
        }

        @Override
        protected Void doInBackground(Booking... bookings){
            bookingDao.delete(bookings[0]);
            return null;
        }
    }

    private static class DeleteAllBookingsAsyncTask extends AsyncTask<Void, Void, Void> {
        private BookingDao bookingDao;

        private DeleteAllBookingsAsyncTask(BookingDao bookingDao){
            this.bookingDao = bookingDao;
        }

        @Override
        protected Void doInBackground(Void... voids){
            bookingDao.deleteAllBookings();
            return null;
        }
    }
}
