package in.inficloud.mypriest.user;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface UserDao {

    @Insert
    void insert(User user);

    @Update
    void update(User user);

    @Delete
    void delete(User user);

    @Query("SELECT * from priest_users WHERE mobile=:mobile AND password=:password")
    List<User> authUser(String mobile, String password);

    @Query("SELECT * from priest_users WHERE mobile=:mobile")
    List<User> getUser(String mobile);

    @Query("SELECT * from priest_users WHERE mobile=:mobile AND priest=1")
    List<User> getPriest(String mobile);

    @Query("SELECT * from priest_users WHERE priest=0")
    LiveData<List<User> >getAllUsers();

    @Query("SELECT * from priest_users WHERE priest=1")
    LiveData<List<User> >getAllPriests();

    @Query("SELECT * from priest_users WHERE priest=0")
    List<User> getUsers();

    @Query("SELECT * from priest_users WHERE priest=1 AND religion=:religion")
    List<User> getReligionPriests(String religion);

    @Query("SELECT * from priest_users WHERE priest=1")
    List<User> getPriests();

}
