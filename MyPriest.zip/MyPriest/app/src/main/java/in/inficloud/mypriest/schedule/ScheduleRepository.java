package in.inficloud.mypriest.schedule;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;

import in.inficloud.mypriest.Database;
import in.inficloud.mypriest.schedule.Schedule;
import in.inficloud.mypriest.schedule.ScheduleDao;

public class ScheduleRepository {
    private ScheduleDao scheduleDao;
    private LiveData<List<Schedule>> allSchedules;

    public ScheduleRepository(Application application) {
        Database database = Database.getInstance(application);
        scheduleDao = database.scheduleDao();
        allSchedules = scheduleDao.getAllSchedules();

    }
    public List<Schedule> getSchedules(String mobile) {
        return scheduleDao.getSchedules(mobile);
    }

    public List<Schedule> getSchedulesForDay(String mobile,String date) {
        return scheduleDao.getSchedulesForDay(mobile,date);
    }

    public void insert(Schedule schedule){
        new InsertScheduleAsyncTask(scheduleDao).execute(schedule);

    }

    public void update(Schedule schedule){
        new UpdateScheduleAsyncTask(scheduleDao).execute(schedule);

    }

    public void delete(Schedule schedule){
        new DeleteScheduleAsyncTask(scheduleDao).execute(schedule);

    }

    public void deleteAllSchedules(){
        new DeleteAllSchedulesAsyncTask(scheduleDao).execute();

    }
    public LiveData<List<Schedule>> getAllSchedule(){

        return allSchedules;
    }

    private static class InsertScheduleAsyncTask extends AsyncTask<Schedule, Void, Void> {
        private ScheduleDao scheduleDao;

        private InsertScheduleAsyncTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Schedule... schedules){
            scheduleDao.insert(schedules[0]);
            return null;
        }
    }

    private static class UpdateScheduleAsyncTask extends AsyncTask<Schedule, Void, Void> {
        private ScheduleDao scheduleDao;

        private UpdateScheduleAsyncTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Schedule... schedules){
            scheduleDao.update(schedules[0]);
            return null;
        }
    }

    private static class DeleteScheduleAsyncTask extends AsyncTask<Schedule, Void, Void> {
        private ScheduleDao scheduleDao;

        private DeleteScheduleAsyncTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Schedule... schedules){
            scheduleDao.delete(schedules[0]);
            return null;
        }
    }

    private static class DeleteAllSchedulesAsyncTask extends AsyncTask<Void, Void, Void> {
        private ScheduleDao scheduleDao;

        private DeleteAllSchedulesAsyncTask(ScheduleDao scheduleDao){
            this.scheduleDao = scheduleDao;
        }

        @Override
        protected Void doInBackground(Void... voids){
            scheduleDao.deleteAllSchedules();
            return null;
        }
    }
}
