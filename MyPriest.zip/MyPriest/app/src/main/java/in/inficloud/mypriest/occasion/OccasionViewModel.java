package in.inficloud.mypriest.occasion;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class OccasionViewModel extends AndroidViewModel {

    private OccasionRepository repository;
    private LiveData<List<Occasion>> allOccasions;
    private List<Occasion> myOccasions;

    public OccasionViewModel(@NonNull Application application) {
        super(application);
        repository = new OccasionRepository(application);
        allOccasions = repository.getAllOccasion();

     }

     public void insert(Occasion occasion){
        repository.insert(occasion);
     }

     public void update(Occasion occasion){
        repository.update(occasion);
     }

    public void delete(Occasion occasion){
        repository.delete(occasion);
    }

    public void deleteAllOccasions(){
        repository.deleteAllOccasions();
    }

    public List<Occasion>  getMyOccasions (String religion) {
        myOccasions=repository.getReligionOccasions(religion);
        return myOccasions;
    };

    public int  getOccasionPrice (String occasion) {
        int price =repository.getOccasionPrice(occasion);
        return price;
    };
    public LiveData<List<Occasion>> getAllOccasions(){
        return allOccasions;
    }
}
