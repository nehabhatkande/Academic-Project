package in.inficloud.mypriest.occasion;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;
import androidx.room.Insert;

import java.util.List;

import in.inficloud.mypriest.Database;
import in.inficloud.mypriest.occasion.Occasion;
import in.inficloud.mypriest.occasion.OccasionDao;

public class OccasionRepository {
    private OccasionDao occasionDao;
    private LiveData<List<Occasion>> allOccasions;
    private List<Occasion> allROccasions;
    private List<Occasion> Occasions;

    public  OccasionRepository(Application application) {
        Database database = Database.getInstance(application);
        occasionDao = database.occasionDao();
        allOccasions = occasionDao.getAllOccasions();
    }

    public void insert(Occasion occasion){
        new InsertOccasionAsyncTask(occasionDao).execute(occasion);

    }

    public void update(Occasion occasion){
        new UpdateOccasionAsyncTask(occasionDao).execute(occasion);

    }

    public void delete(Occasion occasion){
        new DeleteOccasionAsyncTask(occasionDao).execute(occasion);

    }

    public void deleteAllOccasions(){
        new DeleteAllOccasionsAsyncTask(occasionDao).execute();

    }
    public LiveData<List<Occasion>> getAllOccasion(){

        return allOccasions;
    }

    public List<Occasion> getReligionOccasions (String religion) {
        return occasionDao.getReligionOccasions(religion);
    }

    public int getOccasionPrice (String occasion) {
        return occasionDao.getOccasionPrice(occasion);
    }

    private static class InsertOccasionAsyncTask extends AsyncTask<Occasion, Void, Void> {
        private OccasionDao occasionDao;

        private InsertOccasionAsyncTask(OccasionDao occasionDao){
            this.occasionDao = occasionDao;
        }

        @Override
        protected Void doInBackground(Occasion... occasions){
            occasionDao.insert(occasions[0]);
            return null;
        }
    }

    private static class UpdateOccasionAsyncTask extends AsyncTask<Occasion, Void, Void> {
        private OccasionDao occasionDao;

        private UpdateOccasionAsyncTask(OccasionDao occasionDao){
            this.occasionDao = occasionDao;
        }

        @Override
        protected Void doInBackground(Occasion... occasions){
            occasionDao.update(occasions[0]);
            return null;
        }
    }

    private static class DeleteOccasionAsyncTask extends AsyncTask<Occasion, Void, Void> {
        private OccasionDao occasionDao;

        private DeleteOccasionAsyncTask(OccasionDao occasionDao){
            this.occasionDao = occasionDao;
        }

        @Override
        protected Void doInBackground(Occasion... occasions){
            occasionDao.delete(occasions[0]);
            return null;
        }
    }

    private static class DeleteAllOccasionsAsyncTask extends AsyncTask<Void, Void, Void> {
        private OccasionDao occasionDao;

        private DeleteAllOccasionsAsyncTask(OccasionDao occasionDao){
            this.occasionDao = occasionDao;
        }

        @Override
        protected Void doInBackground(Void... voids){
            occasionDao.deleteAllOccasions();
            return null;
        }
    }
}
