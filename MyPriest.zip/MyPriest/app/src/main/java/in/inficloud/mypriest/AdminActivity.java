package in.inficloud.mypriest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import in.inficloud.mypriest.occasion.Occasion;
import in.inficloud.mypriest.occasion.OccasionAdapter;
import in.inficloud.mypriest.occasion.OccasionViewModel;

public class AdminActivity extends AppCompatActivity {
    public static final int ADD_NOTE_REQUEST = 1;
    public static final int EDIT_NOTE_REQUEST = 2;


    private OccasionViewModel occasionViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        FloatingActionButton buttonAddOccasion = findViewById(R.id.button_add_note);
        buttonAddOccasion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminActivity.this, AddEditOccasionActivity.class);
                startActivityForResult(intent, ADD_NOTE_REQUEST);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        final OccasionAdapter adapter = new OccasionAdapter();
        recyclerView.setAdapter(adapter);

        occasionViewModel = ViewModelProviders.of(this).get(OccasionViewModel.class);
        occasionViewModel.getAllOccasions().observe(this, new Observer<List<Occasion>>() {
            @Override
            public void onChanged(@Nullable List<Occasion> occasions) {
                adapter.submitList(occasions);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                occasionViewModel.delete(adapter.getOccasionAt(viewHolder.getAdapterPosition()));
                Toast.makeText(AdminActivity.this, "Occasion Deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new OccasionAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Occasion occasion) {
                Intent intent = new Intent(AdminActivity.this, AddEditOccasionActivity.class);
                intent.putExtra(AddEditOccasionActivity.EXTRA_ID, occasion.getId());
                intent.putExtra(AddEditOccasionActivity.EXTRA_NAME, occasion.getName());
                intent.putExtra(AddEditOccasionActivity.EXTRA_PRICE, occasion.getPrice());
                intent.putExtra(AddEditOccasionActivity.EXTRA_RELIGION, occasion.getReligion());
                //intent.putExtra(AddEditOccasionActivity.EXTRA_DATE, occasion.getDate());
                intent.putExtra(AddEditOccasionActivity.EXTRA_DESCRIPTION, occasion.getDescripton());
                startActivityForResult(intent, EDIT_NOTE_REQUEST);
            }

        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_NOTE_REQUEST && resultCode == RESULT_OK) {
            String name = data.getStringExtra(AddEditOccasionActivity.EXTRA_NAME);
            String price  = data.getStringExtra(AddEditOccasionActivity.EXTRA_PRICE);
            String religion = data.getStringExtra(AddEditOccasionActivity.EXTRA_RELIGION);
            //String date = data.getStringExtra(AddEditOccasionActivity.EXTRA_DATE);
            String decription = data.getStringExtra(AddEditOccasionActivity.EXTRA_DESCRIPTION);

            Occasion occasion = new Occasion(name,religion, decription, Integer.parseInt(price));
            occasionViewModel.insert(occasion);

            Toast.makeText(this, "Occasion Saved", Toast.LENGTH_SHORT).show();

        } else if (requestCode == EDIT_NOTE_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(AddEditOccasionActivity.EXTRA_ID, -1);

            if (id == -1) {
                Toast.makeText(this, "Occasion can't be updated ", Toast.LENGTH_SHORT).show();
                return;
            }
            String name = data.getStringExtra(AddEditOccasionActivity.EXTRA_NAME);
            String price = data.getStringExtra(AddEditOccasionActivity.EXTRA_PRICE);
            String religion = data.getStringExtra(AddEditOccasionActivity.EXTRA_RELIGION);
            //String date = data.getStringExtra(AddEditOccasionActivity.EXTRA_DATE);
            String description = data.getStringExtra(AddEditOccasionActivity.EXTRA_DESCRIPTION);

            Occasion occasion = new Occasion(name,religion, description,Integer.parseInt(price));
            occasion.setId(id);
            occasionViewModel.update(occasion);

            Toast.makeText(this, "Occasion updated", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Occasion Not Saved", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_all_occasions:
                occasionViewModel.deleteAllOccasions();
                Toast.makeText(this, "All occasions deleted", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
