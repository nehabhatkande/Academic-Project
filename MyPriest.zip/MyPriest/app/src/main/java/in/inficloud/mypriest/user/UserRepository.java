package in.inficloud.mypriest.user;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.ArrayList;
import java.util.List;

import in.inficloud.mypriest.Database;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserDao;

public class UserRepository {

    private UserDao userDao;
    private List<User> users;
    private List<User> priests;
    private LiveData<List<User>> allUsers;
    private LiveData<List<User>> allPriests;
    private LiveData<List<User>> deleteAllUsers;
    private MutableLiveData<List<User>> macthedUsers;

    public UserRepository(Application application) {
        Database database = Database.getInstance(application);
        userDao = database.userDao();
        allUsers = userDao.getAllUsers();
        allPriests = userDao.getAllPriests();
        users = userDao.getUsers();
        priests = userDao.getPriests();
    }

    public void insert(User user) {
        new InsertAsyncTask(userDao).execute(user);
    }

    public void delete(User user) {
        new DeleteAsyncTask(userDao).execute(user);
    }

    public void update(User user) {
        new UpdateAsyncTask(userDao).execute(user);
    }

/*    public void auth(String mobile, String passwd) {
        ArrayList<String> credentials = new ArrayList<String>();
        credentials.add(mobile);
        credentials.add(passwd);
        AuthAsyncTask task = new AuthAsyncTask(userDao);
        task.delegate = this;
        task.execute(credentials);
    }
*/

    public List<User> auth(String email, String passwd) {
        return userDao.authUser(email,passwd);
    }

    public List<User> get(String mobile) {
        return userDao.getUser(mobile);
    }

    public List<User> getUser(String mobile) {
        return userDao.getUser(mobile);
    }

    public List<User> getPriest(String mobile) {
        return userDao.getPriest(mobile);
    }


    public List<User> getReligionPriests(String religion) {
        return userDao.getReligionPriests(religion);
    }

    public List<User> getUsers() {
        return users;
    }

    public List<User> getPriests() {
        return priests;
    }

    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    public LiveData<List<User>> getAllPriests() {
        return allPriests;
    }

    //public LiveData<List<User>> deleteAllUsers() {
        //return allPriests;
    //}



    private static class InsertAsyncTask extends AsyncTask<User, Void, Void> {

        private UserDao userDao;

        private InsertAsyncTask(UserDao userDao){
            this.userDao = userDao;
        }
        @Override
        protected Void doInBackground(User... users) {
            userDao.insert(users[0]);
            return null;
        }
    }


    private static class DeleteAsyncTask extends AsyncTask<User, Void, Void> {

        private UserDao userDao;

        private DeleteAsyncTask(UserDao userDao){
            this.userDao = userDao;
        }
        @Override
        protected Void doInBackground(User... users) {
            userDao.delete(users[0]);
            return null;
        }
    }


    private static class UpdateAsyncTask extends AsyncTask<User, Void, Void> {

        private UserDao userDao;

        private UpdateAsyncTask(UserDao userDao){
            this.userDao = userDao;
        }
        @Override
        protected Void doInBackground(User... users) {
            userDao.update(users[0]);
            return null;
        }
    }
    private static class AuthAsyncTask extends AsyncTask<List<String>, Void, List<User>> {

        private UserDao userDao;
        private UserRepository delegate = null;
        private AuthAsyncTask(UserDao userDao){
            this.userDao = userDao;
        }
        @Override
        protected List<User> doInBackground(List... user) {
            return userDao.authUser(user[0].get(0).toString(), user[0].get(1).toString());
        }@Override
        protected void onPostExecute(List<User> result) {
            delegate.authFinished(result);
        }

    }
    private void authFinished(List<User> results) {
        macthedUsers.setValue(results);
    }

}
