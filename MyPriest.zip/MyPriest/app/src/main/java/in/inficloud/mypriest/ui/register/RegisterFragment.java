package in.inficloud.mypriest.ui.register;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.jaredrummler.materialspinner.MaterialSpinner;

import in.inficloud.mypriest.R;
import in.inficloud.mypriest.user.User;

import static android.content.ContentValues.TAG;

public class RegisterFragment extends Fragment {

    private RegisterViewModel registerViewModel;
    private TextInputEditText editTextFirstName;
    private TextInputEditText editTextLastName;
    private TextInputEditText editTextEmail;
    private TextInputEditText editTextMobile;
    private TextInputEditText editTextPassword;
    private TextInputEditText editTextRepeatPassword;
    private CheckBox checkBoxPriest;
    private MaterialButton btnRegister;
    private int isPriest = 0;
    String sFirstName, sLastName, sEmail, sMobile, sPassword, sRepeatPassword, sReligion;
    Boolean bPriest;
    private Boolean verifySuccess = true;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        registerViewModel =
                ViewModelProviders.of(this).get(RegisterViewModel.class);

        View root = inflater.inflate(R.layout.fragment_register, container, false);

        editTextFirstName = root.findViewById(R.id.fname);
        editTextLastName = root.findViewById(R.id.lname);
        editTextMobile = root.findViewById(R.id.mobile);
        editTextEmail = root.findViewById(R.id.mobno);
        editTextPassword = root.findViewById(R.id.password);
        editTextRepeatPassword = root.findViewById(R.id.rpassword);
        checkBoxPriest = root.findViewById(R.id.priest);
        btnRegister = root.findViewById(R.id.register);

        final MaterialSpinner spinner = root.findViewById(R.id.religion);
        spinner.setItems("Select Religion", "Hindu", "Muslim", "Christian", "Sikh");
        sReligion = "Select Religion";

        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {

            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                Snackbar.make(view, "Clicked " + item, Snackbar.LENGTH_LONG).show();
                sReligion = item;
            }


        });

        bPriest = checkBoxPriest.isChecked();

        checkBoxPriest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d(TAG, "onClick: "+checkBoxPriest.isChecked());
                bPriest = checkBoxPriest.isChecked();
                if (checkBoxPriest.isChecked()) {
                    isPriest=1;
                    Snackbar.make(v, "you are a priest", Snackbar.LENGTH_LONG).show();
                } else {
                    isPriest=0;
                    Snackbar.make(v, "you are not a priest", Snackbar.LENGTH_LONG).show();
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sFirstName = editTextFirstName.getText().toString();
                sLastName = editTextLastName.getText().toString();
                sMobile = editTextMobile.getText().toString();
                sEmail = editTextEmail.getText().toString();
                sPassword = editTextPassword.getText().toString();
                sRepeatPassword = editTextRepeatPassword.getText().toString();

                Log.d("RegisterFragment", "onClick: User Submit");
                verifyInput();
                if (verifySuccess) {


                    User user = new User(sFirstName, sLastName, sEmail, sMobile, sPassword, sReligion, isPriest, null,null);
                    registerViewModel.insert(user);
                    Snackbar.make(v, "Registered Successfully!!Go to Login Page", Snackbar.LENGTH_LONG).show();
                } else {
                    verifySuccess = true;
                }
            }
        });

        return root;
    }

    private void verifyInput() {
        sFirstName = editTextFirstName.getText().toString();
        sLastName = editTextLastName.getText().toString();
        sMobile = editTextMobile.getText().toString();
        sEmail = editTextEmail.getText().toString();
        sPassword = editTextPassword.getText().toString();
        sRepeatPassword = editTextRepeatPassword.getText().toString();

        verifyFirstName(sFirstName);
        verifyLastName(sLastName);
        verifyMobileNo(sMobile);
        verifyEmail(sEmail);
        verifyPassword(sPassword);
        verifyRepeatPassword(sRepeatPassword);
        verifyReligion(sReligion);


    }

    private void verifyReligion(String sReligion) {
        if (sReligion.equals("Select Religion") ){
            Snackbar.make(getView(), "Please select Religion", Snackbar.LENGTH_LONG).show();
            verifySuccess = false;
        }
    }

    private void verifyFirstName(String sFirstName) {

        Log.d(TAG, "verifyFirstName: " + sFirstName);
        if (!(sFirstName.matches("[a-z A-Z]+"))) {
            editTextFirstName.setError("Invalid First Name");
            verifySuccess = false;
        }
    }

    private void verifyLastName(String sLastName) {
        Log.d(TAG, "verifyLastName: " + sLastName);
        if (!(sLastName.matches("[a-z A-Z]+"))) {
            editTextLastName.setError("Invalid Last Name");
            verifySuccess = false;
        }
    }

    private void verifyMobileNo(String sMobile) {
        Log.d(TAG, "verifyMobileNo: " + sMobile);

        if (sMobile.isEmpty() ) {
            editTextMobile.setError("This field can't be empty");
            verifySuccess = false;
        }
        else if (sMobile.length() < 10)
        {
            editTextMobile.setError("Please enter 10 digit number");
        }
        if (!sMobile.matches("(0/91)?[6-9][0-9]{9}")){
            editTextMobile.setError("Please enter valid Mobile Number");
            verifySuccess = false;
        }

    }

    private void verifyEmail(String sEmail) {
        Log.d(TAG, "verifyEmail: " + sEmail);
        String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+.+[a-z]";
        if (!(sEmail.matches(emailPattern))) {
            editTextEmail.setError("Invalid Email ID");
            verifySuccess = false;
        }
    }

    private void verifyPassword(String sPassword) {
        Log.d(TAG, "verifyeditTextPassword: " + sPassword);
        String sPasswordPattern = ("^" + "(?=.*[0-9])" + "(?=.*[a-z])" +
                "(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$)" + ".{8,18}" + "$");
        if (sPassword.isEmpty()) {
            editTextPassword.setError("Password field can't be empty");
        } else if (sPassword.length() < 8) {
            editTextPassword.setError("Minimum 8 characters ");
            verifySuccess = false;
        }

        else if(!(sPassword.matches(sPasswordPattern)))

    {
        editTextPassword.setError("Password too weak!!");
        verifySuccess = false;

    }

}

    private void verifyRepeatPassword(String sRepeatPassword) {
        Log.d(TAG, "verifyeditTextRepeatPassword: " + sRepeatPassword);
        String sPasswordPattern = ("^" + "(?=.*[0-9])" + "(?=.*[a-z])" +
                "(?=.*[A-Z])" + "(?=.*[@#$%^&+=])" + "(?=\\S+$)" + ".{8}" + "$");
        if (sRepeatPassword.isEmpty())
        {
            editTextRepeatPassword.setError("Password field can't be empty");
        }
        if (!(sRepeatPassword.equals(sPassword))) {
            editTextRepeatPassword.setError("Password do not matching");
            verifySuccess = false;

        }


    }

}


