package in.inficloud.mypriest.ui.login;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import java.util.List;

import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserRepository;

public class LoginViewModel extends AndroidViewModel {

    private UserRepository repository;
    private LiveData<List<User>> allUsers;
    private LiveData<List<User>> allPriests;
    private List<User> authUsers;

    public LoginViewModel(@NonNull Application application) {
        super(application);
        repository = new UserRepository(application);
        allUsers = repository.getAllUsers();
        allPriests = repository.getAllPriests();
    }

    public void insert (User user) {
        repository.insert(user);
    }

    public void delete(User user) {
        repository.delete(user);
    }

    public void update(User user) {
        repository.update(user);
    }

    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    public LiveData<List<User>> getAllPriests() {
        return allPriests;
    }

    public List<User> getUser(String mobile) {
        return repository.get(mobile);
    }

    public List<User> getAuthUsers (){return authUsers;}

    public List<User> auth(String mobile, String password) {
        authUsers=repository.auth(mobile, password);
        return authUsers;
    };
}