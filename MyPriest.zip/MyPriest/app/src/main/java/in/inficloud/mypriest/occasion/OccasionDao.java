package in.inficloud.mypriest.occasion;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface OccasionDao {
    @Insert
    void insert(Occasion occasion);

    @Update
    void update(Occasion occasion);

    @Delete
    void delete(Occasion occasion);

    @Query("DELETE FROM priest_occasions")
    void  deleteAllOccasions();

    @Query("SELECT * FROM priest_occasions")
    LiveData<List<Occasion>> getAllOccasions();

    @Query("SELECT * FROM priest_occasions")
    List<Occasion> getOccasions();

    @Query("SELECT * FROM priest_occasions WHERE religion=:religion")
    List<Occasion> getReligionOccasions(String religion);

    @Query("SELECT price FROM priest_occasions WHERE name =:name")
    int getOccasionPrice(String name);

}
