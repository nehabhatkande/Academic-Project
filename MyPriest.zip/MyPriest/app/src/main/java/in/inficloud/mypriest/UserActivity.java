package in.inficloud.mypriest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import in.inficloud.mypriest.booking.Booking;
import in.inficloud.mypriest.booking.BookingAdapter;
import in.inficloud.mypriest.booking.BookingViewModel;
import in.inficloud.mypriest.schedule.Schedule;
import in.inficloud.mypriest.schedule.ScheduleDao;
import in.inficloud.mypriest.schedule.ScheduleViewModel;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserViewModel;

import static in.inficloud.mypriest.PriestActivity.ADD_ADDRESS_REQUEST;

public class UserActivity extends AppCompatActivity {
    public static final int ADD_NOTE_REQUEST = 1;
    public static final int EDIT_NOTE_REQUEST = 2;
    public static final int ADD_ADDRESS_REQUEST = 3;
    public static final int CANCEL_NOTE_REQUEST = 4;
    private static final String TAG = "TIME";
    private String sReligion;
    private String sUser;
    private Booking priestCancel;
    private BookingAdapter adapter;
    private String sPriest;
    private BookingViewModel bookingViewModel;
    private UserViewModel userViewModel;
    List <Integer> scheduleTime = Arrays.asList(0,0,0,0,0,0,0,0,0,0,0,0);
    private ScheduleViewModel scheduleViewModel;
    private  double lat;
    private double lan;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        Bundle b = getIntent().getExtras();
        sUser = b.getString("name");
        sReligion = b.getString("religion");
         lat = b.getDouble("lat");
        lan = b.getDouble("lan");

        FloatingActionButton buttonAddBooking = findViewById(R.id.button_add_booking);
        buttonAddBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                if (lat == 0  && lan == 0){
                    intent = new Intent(UserActivity.this, UserCustomMarkerClusteringDemoActivity.class);
                    intent.putExtra("religion", sReligion);
                    startActivityForResult(intent, ADD_ADDRESS_REQUEST);
                }
                else{
                    intent = new Intent(UserActivity.this, AddEditBookingActivity.class);
                    intent.putExtra("religion", sReligion);
                    startActivityForResult(intent, ADD_NOTE_REQUEST);
                }




            }
        });

        FloatingActionButton buttonAddAddress = findViewById(R.id.button_user_profile);
        buttonAddAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserActivity.this, UserCustomMarkerClusteringDemoActivity.class);
                intent.putExtra("religion", sReligion);
                startActivityForResult(intent, ADD_ADDRESS_REQUEST);
            }
        });

        RecyclerView recyclerView = findViewById(R.id.recycler_view_user);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        adapter = new BookingAdapter();
        recyclerView.setAdapter(adapter);

        scheduleViewModel = ViewModelProviders.of(this).get(ScheduleViewModel.class);
        userViewModel= ViewModelProviders.of(this).get(UserViewModel.class);
        bookingViewModel = ViewModelProviders.of(this).get(BookingViewModel.class);
        bookingViewModel.getAllBookingsMobile(sUser).observe(this, new Observer<List<Booking>>() {
            @Override
            public void onChanged(@Nullable List<Booking> bookings) {
                adapter.submitList(bookings);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                bookingViewModel.delete(adapter.getBookingAt(viewHolder.getAdapterPosition()));
                Toast.makeText(UserActivity.this, "Booking Deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new BookingAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Booking booking) {
                List<User> priests = userViewModel.getPriest(booking.getPriest());



                Log.d(TAG, "onBindViewHolder: "+priests);
                Log.d(TAG, "onBindViewHolder: "+booking.getUser());
                Double lat = priests.get(0).getLatitude();
                Double lang = priests.get(0).getLongitude();
                String fname = priests.get(0).getFname();
                String lname = priests.get(0).getLname();

                Geocoder geocoder;
                List<Address> addresses = null;
                geocoder = new Geocoder(getApplicationContext());

                Log.d(TAG, "onBindViewHolder: "+lat);
                Log.d(TAG, "onBindViewHolder: "+lang);

                try {
                    if (lat != null && lang != null)
                        addresses = geocoder.getFromLocation(lat, lang, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String address = " ";
                String city = " ";
                String state = " ";
                String country = " ";
                String postalCode = " ";
                if (lat != null && lang != null) {
                    //address = addresses.get(0).getSubLocality();
                    address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                    city = addresses.get(0).getLocality();
                    state = addresses.get(0).getAdminArea();
                    country = addresses.get(0).getCountryName();
                    postalCode = addresses.get(0).getPostalCode();


                }

                priestCancel = booking;
                Intent intent = new Intent(UserActivity.this,CancelActivity.class);
                intent.putExtra(AddEditBookingActivity.EXTRA_ID, booking.getId());
                intent.putExtra("name", booking.getName());
                intent.putExtra("religion", booking.getReligion());
                intent.putExtra("date", booking.getDate());
                intent.putExtra("time", booking.getTime());
                intent.putExtra("priest", booking.getPriest());
                intent.putExtra("location",address);
                intent.putExtra("fname",fname);
                intent.putExtra("lname",lname);
                //intent.putExtra(AddEditBookingActivity.EXTRA_DESCRIPTION, booking.getDescripton());
                //intent.putExtra("religion", sReligion);
                startActivityForResult(intent, CANCEL_NOTE_REQUEST);
            }

        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_NOTE_REQUEST && resultCode == RESULT_OK) {
            String name = data.getStringExtra(AddEditBookingActivity.EXTRA_NAME);
            String religion = sReligion;
            String date = data.getStringExtra(AddEditBookingActivity.EXTRA_DATE);
            String priest = data.getStringExtra(AddEditBookingActivity.EXTRA_PRIEST);
            String user = sUser;
            String status = "new";
            String time = data.getStringExtra(AddEditBookingActivity.EXTRA_TIME);
            String [] parts = time.split( ":");
            Log.d(TAG, "onActivityResult: "+Integer.parseInt(parts[0]));
            scheduleTime.set(Integer.parseInt(parts[0]),1);



            //String decription = data.getStringExtra(AddEditBookingActivity.EXTRA_DESCRIPTION);

            Booking booking = new Booking(name, date,time,priest,user,religion,status);
            bookingViewModel.insert(booking);
            Log.d(TAG, "onActivityResult: "+priest);
            Log.d(TAG, "onActivityResult: "+date);

            List<Schedule>  dayschedule = scheduleViewModel.getMySchedulesForDay(priest,date);
            if (dayschedule.size() != 0)
            {
                Schedule schedule = dayschedule.get(0);
                List <Integer> stime = new ArrayList<>();
                Log.d(TAG, "onActivityResult: "+stime.size());
                stime.add(0,schedule.getTime01());
                stime.add(1,schedule.getTime02());
                stime.add(2,schedule.getTime03());
                stime.add(3,schedule.getTime04());
                stime.add(4,schedule.getTime05());
                stime.add(5,schedule.getTime06());
                stime.add(6,schedule.getTime07());
                stime.add(7,schedule.getTime08());
                stime.add(8,schedule.getTime09());
                stime.add(9,schedule.getTime10());
                stime.add(10,schedule.getTime11());
                stime.add(11,schedule.getTime12());

                stime.set(Integer.parseInt(parts[0]),1);

                schedule.setTime01(stime.get(0));
                schedule.setTime02(stime.get(1));
                schedule.setTime03(stime.get(2));
                schedule.setTime04(stime.get(3));
                schedule.setTime05(stime.get(4));
                schedule.setTime06(stime.get(5));
                schedule.setTime07(stime.get(6));
                schedule.setTime08(stime.get(7));
                schedule.setTime09(stime.get(8));
                schedule.setTime10(stime.get(9));
                schedule.setTime11(stime.get(10));
                schedule.setTime12(stime.get(11));

                scheduleViewModel.update(schedule);

            }
            else {
                Schedule schedule = new Schedule(priest,date,scheduleTime.get(0),scheduleTime.get(1),scheduleTime.get(2),scheduleTime.get(3),
                        scheduleTime.get(4),scheduleTime.get(5),scheduleTime.get(6),scheduleTime.get(7),scheduleTime.get(8),scheduleTime.get(9),
                        scheduleTime.get(10),scheduleTime.get(11));
                scheduleViewModel.insert(schedule);
            }

            Toast.makeText(this, "Booking Saved", Toast.LENGTH_SHORT).show();

        } else if (requestCode == EDIT_NOTE_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(AddEditBookingActivity.EXTRA_ID, -1);

            if (id == -1) {
                Toast.makeText(this, "Booking can't be updated ", Toast.LENGTH_SHORT).show();
                return;
            }
            String name = data.getStringExtra(AddEditBookingActivity.EXTRA_NAME);
            String religion = sReligion;
            String date = data.getStringExtra(AddEditBookingActivity.EXTRA_DATE);
            String priest = data.getStringExtra(AddEditBookingActivity.EXTRA_PRIEST);
            String user = sUser;
            String status = "new";
            String time = data.getStringExtra(AddEditBookingActivity.EXTRA_TIME);
            Log.d(TAG, "onActivityResult: "+time);
            //String description = data.getStringExtra(AddEditBookingActivity.EXTRA_DESCRIPTION);

            Booking booking = new Booking(name, date,time,priest,user,religion,status);
            booking.setId(id);
            bookingViewModel.update(booking);

            Toast.makeText(this, "Booking updated", Toast.LENGTH_SHORT).show();
        }
        else if (requestCode == ADD_ADDRESS_REQUEST && resultCode == RESULT_OK) {

            userViewModel =
                    ViewModelProviders.of(this).get(UserViewModel .class);

            Log.d(TAG, "onActivityResult: gotresults");
            Double latitude = data.getDoubleExtra(CustomMarkerClusteringDemoActivity.EXTRA_LATITUDE,0.0);
            Double longitude = data.getDoubleExtra(CustomMarkerClusteringDemoActivity.EXTRA_LANGITUDE,0.0);
            Log.d(TAG, "onActivityResult: "+latitude);
            Log.d(TAG, "onActivityResult: "+longitude);
            List<User> priests = userViewModel.getUser(sUser);

            priests.get(0).setLatitude(latitude);
            priests.get(0).setLongitude(longitude);
            lat = latitude;
            lan = longitude;
            userViewModel.update(priests.get(0));

            Toast.makeText(this, "Booking Saved", Toast.LENGTH_SHORT).show();

        }
        else if (requestCode == CANCEL_NOTE_REQUEST && resultCode == RESULT_OK)
        {
            int id = data.getIntExtra(ConfirmRejectActivity.EXTRA_ID, -1);
            String name = priestCancel.getName();
            //String religion = sReligion;
            String religion = priestCancel.getReligion();
            //String date = data.getStringExtra(AddEditBookingActivity.EXTRA_DATE);
            String date = priestCancel.getDate();
            //String time = data.getStringExtra(AddEditBookingActivity.EXTRA_TIME);
            String time = priestCancel.getTime();
            //String user = data.getStringExtra(AddEditBookingActivity.EXTRA_USER);
            String user = priestCancel.getUser();
            //String priest = data.getStringExtra(AddEditBookingActivity.EXTRA_PRIEST);
            //String priest = sPriest;
            String priest = priestCancel.getPriest();

            String status = data.getStringExtra(ConfirmRejectActivity.EXTRA_STATUS );
            Log.d(TAG, "onActivityResult: "+status);
            if ( status.equals("cancel"))
            {
                Toast.makeText(this,"Booking Cancelled",Toast.LENGTH_SHORT).show();
                Log.d(TAG, "onActivityResult: "+status);
                List<Schedule> dayschedule = scheduleViewModel.getMySchedulesForDay(priest,date);
                //Schedule dayschedule = schedules.get(0);
                Log.d(TAG, "onActivityResult: "+priest);
                Log.d(TAG, "onActivityResult: "+date);
                Log.d(TAG, "onActivityResult: "+dayschedule);
                Log.d(TAG, "onActivityResult: "+time);
                String [] parts = time.split( ":");

                if (dayschedule.size() != 0) {
                    Schedule schedule = dayschedule.get(0);
                    List<Integer> stime = new ArrayList<>();
                    Log.d(TAG, "onActivityResult: " + stime.size());
                    stime.add(0, schedule.getTime01());
                    stime.add(1, schedule.getTime02());
                    stime.add(2, schedule.getTime03());
                    stime.add(3, schedule.getTime04());
                    stime.add(4, schedule.getTime05());
                    stime.add(5, schedule.getTime06());
                    stime.add(6, schedule.getTime07());
                    stime.add(7, schedule.getTime08());
                    stime.add(8, schedule.getTime09());
                    stime.add(9, schedule.getTime10());
                    stime.add(10, schedule.getTime11());
                    stime.add(11, schedule.getTime12());

                    stime.set(Integer.parseInt(parts[0]), 0);
                    Log.d(TAG, "onActivityResult: "+parts[0]);

                    schedule.setTime01(stime.get(0));
                    schedule.setTime02(stime.get(1));
                    schedule.setTime03(stime.get(2));
                    schedule.setTime04(stime.get(3));
                    schedule.setTime05(stime.get(4));
                    schedule.setTime06(stime.get(5));
                    schedule.setTime07(stime.get(6));
                    schedule.setTime08(stime.get(7));
                    schedule.setTime09(stime.get(8));
                    schedule.setTime10(stime.get(9));
                    schedule.setTime11(stime.get(10));
                    schedule.setTime12(stime.get(11));

                    scheduleViewModel.update(schedule);
                }

            }
            //String name = data.getStringExtra(AddEditBookingActivity.EXTRA_NAME);
            //String status = sReligion;
            //String sStatus = data.getStringExtra(AddEditBookingActivity.EXTRA_STATUS);
            //String status = priestConfirm.getStatus();

            // Booking booking = new Booking(name, religion, date,time, priest, user,status);
            //booking.setId(id);
            priestCancel.setStatus(status);

            bookingViewModel.update(priestCancel);
            adapter.notifyDataSetChanged();

            Toast.makeText(this, "Booking updated", Toast.LENGTH_SHORT).show();
        }



        else {
            Toast.makeText(this, "Booking Not Saved", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu_bookings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_all_bookings:
                bookingViewModel.deleteAllBookings();
                Toast.makeText(this, "All bookings deleted", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
