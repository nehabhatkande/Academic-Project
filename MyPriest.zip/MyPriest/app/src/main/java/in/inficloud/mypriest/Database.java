package in.inficloud.mypriest;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import in.inficloud.mypriest.booking.Booking;
import in.inficloud.mypriest.booking.BookingDao;
import in.inficloud.mypriest.occasion.Occasion;
import in.inficloud.mypriest.occasion.OccasionDao;
import in.inficloud.mypriest.schedule.Schedule;
import in.inficloud.mypriest.schedule.ScheduleDao;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserDao;

@androidx.room.Database(entities = {User.class, Occasion.class, Booking.class, Schedule.class}, version = 1)

public abstract class Database extends RoomDatabase {
    private static Database  instance;
    public abstract UserDao userDao();
    public abstract OccasionDao occasionDao();
    public abstract BookingDao bookingDao();
    public abstract ScheduleDao scheduleDao();


    public static synchronized Database getInstance(Context context) {
        if (instance == null ){
            instance = Room.databaseBuilder(context.getApplicationContext(),
                    Database.class,"priest_db")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .addCallback(roomCallback)
                    .build();
        }
        return instance;
    }

    private static RoomDatabase.Callback roomCallback = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
        }
    };
}
