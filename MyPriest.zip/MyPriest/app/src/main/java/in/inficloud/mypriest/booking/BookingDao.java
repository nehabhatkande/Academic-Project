package in.inficloud.mypriest.booking;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

//import in.inficloud.mypriest.booking.Booking;

@Dao
public interface BookingDao {
    @Insert
    void insert(Booking booking);

    @Update
    void update(Booking booking);

    @Delete
    void delete(Booking booking);

    @Query("DELETE FROM priest_bookings")
    void  deleteAllBookings();

    @Query("SELECT * from priest_bookings WHERE user=:mobile")
    List<Booking> getBookings(String mobile);

    @Query("SELECT * from priest_bookings WHERE user=:mobile")
    LiveData<List<Booking>> getAllBookingsMobile(String mobile);

    @Query("SELECT * from priest_bookings WHERE priest=:mobile")
    LiveData<List<Booking>> getPriestBookingsMobile(String mobile);




    @Query("SELECT * FROM priest_bookings")
    LiveData<List<Booking>> getAllBookings();
}
