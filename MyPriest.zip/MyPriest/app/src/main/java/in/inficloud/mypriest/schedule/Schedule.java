package in.inficloud.mypriest.schedule;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity (tableName = "priest_schedules")
public class Schedule {
    @PrimaryKey(autoGenerate = true)
    private int id;
    private String priest;
    private String date;
    private int time01;
    private int time02;
    private int time03;
    private int time04;
    private int time05;
    private int time06;
    private int time07;
    private int time08;
    private int time09;
    private int time10;
    private int time11;
    private int time12;



    public Schedule(String priest, String date, int time01, int time02, int time03, int time04, int time05, int time06, int time07, int time08, int time09, int time10, int time11, int time12) {
        this.priest = priest;

        this.date = date;
        this.time01 = time01;
        this.time02 = time02;
        this.time03 = time03;
        this.time04 = time04;
        this.time05 = time05;
        this.time06 = time06;
        this.time07 = time07;
        this.time08 = time08;
        this.time09 = time09;
        this.time10 = time10;
        this.time11 = time11;
        this.time12 = time12;
    }

    public int getId() {
        return id;
    }

    public String getPriest() {
        return priest;
    }

    public String getDate() {
        return date;
    }

    public int getTime01() {
        return time01;
    }

    public int getTime02() {
        return time02;
    }

    public int getTime03() {
        return time03;
    }

    public int getTime04() {
        return time04;
    }

    public int getTime05() {
        return time05;
    }

    public int getTime06() {
        return time06;
    }

    public int getTime07() {
        return time07;
    }

    public int getTime08() {
        return time08;
    }

    public int getTime09() {
        return time09;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getTime10() {
        return time10;
    }

    public int getTime11() {
        return time11;
    }

    public int getTime12() {
        return time12;
    }


    public void setId(int id) {
        this.id = id;
    }

    public void setPriest(String priest) {
        this.priest = priest;
    }

    public void setTime01(int time01) {
        this.time01 = time01;
    }

    public void setTime02(int time02) {
        this.time02 = time02;
    }

    public void setTime03(int time03) {
        this.time03 = time03;
    }

    public void setTime04(int time04) {
        this.time04 = time04;
    }

    public void setTime05(int time05) {
        this.time05 = time05;
    }

    public void setTime06(int time06) {
        this.time06 = time06;
    }

    public void setTime07(int time07) {
        this.time07 = time07;
    }

    public void setTime08(int time08) {
        this.time08 = time08;
    }

    public void setTime09(int time09) {
        this.time09 = time09;
    }

    public void setTime10(int time10) {
        this.time10 = time10;
    }

    public void setTime11(int time11) {
        this.time11 = time11;
    }

    public void setTime12(int time12) {
        this.time12 = time12;
    }


}
