/*
 * Copyright 2013 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package in.inficloud.mypriest;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.ClusterItem;
import com.google.maps.android.clustering.ClusterManager;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.google.maps.android.ui.IconGenerator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import in.inficloud.mypriest.user.Person;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserDao;
import in.inficloud.mypriest.user.UserRepository;

/**
 * Demonstrates heavy customisation of the look of rendered clusters.
 */
public class UserCustomMarkerClusteringDemoActivity extends BaseDemoActivity implements ClusterManager.OnClusterClickListener<Person>, ClusterManager.OnClusterInfoWindowClickListener<Person>, ClusterManager.OnClusterItemClickListener<Person>, ClusterManager.OnClusterItemInfoWindowClickListener<Person> {
    private static final String TAG =  "CUSTOM MARKER";
    private ClusterManager<Person> mClusterManager;
    private Random mRandom = new Random(1984);
    private UserDao userViewModel;
    private GoogleMap mMap;
    private String sPriest;

    public static final String EXTRA_ID =
            "com.example.architectureexample.EXTRA_ID";

    public static final String EXTRA_LATITUDE = "Latitude";
    public static final String EXTRA_LANGITUDE = "Langitude";
    private UserRepository userRepository;


    /**
     * Draws profile photos inside markers (using IconGenerator).
     * When there are multiple people in the cluster, draw multiple photos (using MultiDrawable).
     */
    private class PersonRenderer extends DefaultClusterRenderer<Person> {
        private final IconGenerator mIconGenerator = new IconGenerator(getApplicationContext());
        private final IconGenerator mClusterIconGenerator = new IconGenerator(getApplicationContext());
        private final ImageView mImageView;
        private final ImageView mClusterImageView;
        private final int mDimension;

        public PersonRenderer() {
            super(getApplicationContext(), getMap(), mClusterManager);

            View multiProfile = getLayoutInflater().inflate(R.layout.multi_profile, null);
            mClusterIconGenerator.setContentView(multiProfile);
            mClusterImageView = (ImageView) multiProfile.findViewById(R.id.image);

            mImageView = new ImageView(getApplicationContext());
            mDimension = (int) getResources().getDimension(R.dimen.custom_profile_image);
            mImageView.setLayoutParams(new ViewGroup.LayoutParams(mDimension, mDimension));
            int padding = (int) getResources().getDimension(R.dimen.custom_profile_padding);
            mImageView.setPadding(padding, padding, padding, padding);
            mIconGenerator.setContentView(mImageView);
        }

        @Override
        protected void onBeforeClusterItemRendered(Person person, MarkerOptions markerOptions) {
            // Draw a single person.
            // Set the info window to show their name.
            mImageView.setImageResource(person.profilePhoto);
            Bitmap icon = mIconGenerator.makeIcon();
            markerOptions.icon(BitmapDescriptorFactory.fromBitmap(icon)).title(person.name);
        }

        @Override
        protected void onBeforeClusterRendered(Cluster<Person> cluster, MarkerOptions markerOptions) {
            // Draw multiple people.
            // Note: this method runs on the UI thread. Don't spend too much time in here (like in this example).
            List<Drawable> profilePhotos = new ArrayList<Drawable>(Math.min(4, cluster.getSize()));
            int width = mDimension;
            int height = mDimension;

            for (Person p : cluster.getItems()) {
                // Draw 4 at most.
                if (profilePhotos.size() == 4) break;
                Drawable drawable = getResources().getDrawable(p.profilePhoto);
                drawable.setBounds(0, 0, width, height);
                profilePhotos.add(drawable);
            }
            MultiDrawable multiDrawable = new MultiDrawable(profilePhotos);
            multiDrawable.setBounds(0, 0, width, height);

            mClusterImageView.setImageDrawable(multiDrawable);
            Bitmap icon = mClusterIconGenerator.makeIcon(String.valueOf(cluster.getSize()));
            markerOptions.icon(BitmapDescriptorFactory.fromBitmap(icon));
        }

        @Override
        protected boolean shouldRenderAsCluster(Cluster cluster) {
            // Always render clusters.
            return cluster.getSize() > 1;
        }
    }

    @Override
    public boolean onClusterClick(Cluster<Person> cluster) {
        // Show a toast with some info when the cluster is clicked.
        String firstName = cluster.getItems().iterator().next().name;
        Toast.makeText(this, cluster.getSize() + " (including " + firstName + ")", Toast.LENGTH_SHORT).show();

        // Zoom in the cluster. Need to create LatLngBounds and including all the cluster items
        // inside of bounds, then animate to center of the bounds.

        // Create the builder to collect all essential cluster items for the bounds.
        LatLngBounds.Builder builder = LatLngBounds.builder();
        for (ClusterItem item : cluster.getItems()) {
            builder.include(item.getPosition());
        }
        // Get the LatLngBounds
        final LatLngBounds bounds = builder.build();

        // Animate camera to the bounds
        try {
            getMap().animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    @Override
    public void onClusterInfoWindowClick(Cluster<Person> cluster) {
        // Does nothing, but you could go to a list of the users.
    }

    @Override
    public boolean onClusterItemClick(Person item) {
        // Does nothing, but you could go into the user's profile page, for example.
        return false;
    }

    @Override
    public void onClusterItemInfoWindowClick(Person item) {
        // Does nothing, but you could go into the user's profile page, for example.
    }

    @Override
    protected void startDemo(boolean isRestore) {
        /*Bundle b = getIntent().getExtras();
        sPriest = b.getString("name");*/
       // sReligion = b.getString("religion");
        if (!isRestore) {
            getMap().moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(15.8497, 74.4977), 9.5f));
        }
       /* ArrayList<String> names =getIntent().getExtras().getStringArrayList("names");
        double[] latitudes = getIntent().getExtras().getDoubleArray("latitudes");
        double[] longitudes = getIntent().getExtras().getDoubleArray("longitudes");*/

        mMap = getMap();
        /*
        Log.d(TAG, "startDemo: "+latitudes.toString());
        Log.d(TAG, "startDemo: "+longitudes.toString());
        LatLng newLatLng = new LatLng(latitudes[0],longitudes[0]);


        MarkerOptions markerOptions = new MarkerOptions()
                .position(newLatLng)
                .title(newLatLng.toString());

        mMap.addMarker(markerOptions);*/

        mMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {

            @Override
            public void onMapClick(LatLng point) {
                //myMap.addMarker(new MarkerOptions().position(point).title(point.toString()));

                //The code below demonstrate how to convert between LatLng and Location

                //Convert LatLng to Location
                Location location = new Location("Test");
                location.setLatitude(point.latitude);
                location.setLongitude(point.longitude);
                location.setTime(new Date().getTime()); //Set time as current Date
                //txtinfo.setText(location.toString());
                Log.d("MAP", "onMapClick: "+location.toString()+sPriest);
                //Convert Location to LatLng
                LatLng newLatLng = new LatLng(location.getLatitude(), location.getLongitude());

                MarkerOptions markerOptions = new MarkerOptions()
                        .position(newLatLng)
                        .title(newLatLng.toString());

                mMap.addMarker(markerOptions);

                Intent  data = new Intent();
                data.putExtra(EXTRA_LATITUDE, location.getLatitude());
                data.putExtra(EXTRA_LANGITUDE, location.getLongitude());



                int id  = getIntent().getIntExtra(EXTRA_ID, -1);
                Log.d(TAG, "onMapClick: "+id);
                if (id != -1){
                    data.putExtra(EXTRA_ID,id);

                }
                Log.d(TAG, "onMapClick: "+id);

                setResult(RESULT_OK, data);
                finish();


            }
        });

        mClusterManager = new ClusterManager<Person>(this, getMap());
        mClusterManager.setRenderer(new PersonRenderer());
        getMap().setOnCameraIdleListener(mClusterManager);
        getMap().setOnMarkerClickListener(mClusterManager);
        getMap().setOnInfoWindowClickListener(mClusterManager);
        mClusterManager.setOnClusterClickListener(this);
        mClusterManager.setOnClusterInfoWindowClickListener(this);
        mClusterManager.setOnClusterItemClickListener(this);
        mClusterManager.setOnClusterItemInfoWindowClickListener(this);


        addItems();

        mClusterManager.cluster();
    }

    private void addItems() {
        userRepository = new UserRepository(getApplication());
        List<User> users = userRepository.getUsers();
        List<User> priests = userRepository.getPriests();
        List <String> priestnames = new ArrayList<>();
        priestnames.add("Select Priest");
        for (User user:priests) {
            priestnames.add(user.getFname()+" "+user.getLname());

           // mClusterManager.addItem(new Person(user.getPosition(), "Shri "+user.getFname() +" "+user.getLname() , R.drawable.ic_user));
            if (user.getLatitude() != null && user.getLongitude() != null) {


                mClusterManager.addItem(new Person(new LatLng(user.getLatitude(), user.getLongitude()), "Shri " + user.getFname() + " " + user.getLname(), R.drawable.priest));
            }

        }

        for (User user:users) {
            priestnames.add(user.getFname()+" "+user.getLname());

            // mClusterManager.addItem(new Person(user.getPosition(), "Shri "+user.getFname() +" "+user.getLname() , R.drawable.ic_user));
            if (user.getLatitude() != null && user.getLongitude() != null) {


                mClusterManager.addItem(new Person(new LatLng(user.getLatitude(), user.getLongitude()), "Shri " + user.getFname() + " " + user.getLname(), R.drawable.user));
            }

        }

    }

    private LatLng position() {

        LatLng ll = new LatLng(random(15.8497, 15.9177), random( 74.4008,74.4500));
        Toast.makeText(getApplicationContext(), ll.toString(), Toast.LENGTH_LONG);
        return ll;
    }

    private double random(double min, double max) {
        return mRandom.nextDouble() * (max - min) + min;
    }
}
