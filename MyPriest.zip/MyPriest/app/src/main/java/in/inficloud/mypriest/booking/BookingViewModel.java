package in.inficloud.mypriest.booking;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

import in.inficloud.mypriest.booking.Booking;

public class BookingViewModel extends AndroidViewModel {

    private BookingRepository repository;
    private LiveData<List<Booking>> allBookings;
    private List<Booking> myBookings;

    public BookingViewModel(@NonNull Application application) {
        super(application);
        repository = new BookingRepository(application);
        allBookings = repository.getAllBooking();

     }

     public void insert(Booking booking){
        repository.insert(booking);
     }

     public void update(Booking booking){
        repository.update(booking);
     }

    public void delete(Booking booking){
        repository.delete(booking);
    }

    public void deleteAllBookings(){
        repository.deleteAllBookings();
    }

    public LiveData<List<Booking>> getAllBookings(){
        return allBookings;
    }

    public LiveData<List<Booking>> getAllBookingsMobile(String mobile){
         LiveData<List<Booking>> bookings = repository.getAllBookingsMobile(mobile);
        return bookings;
    }

    public LiveData<List<Booking>> getPriestBookingsMobile(String mobile){
        LiveData<List<Booking>> bookings = repository.getPriestBookingsMobile(mobile);
        return bookings;
    }


    public List<Booking> auth(String mobile) {
        myBookings=repository.getBookings(mobile);
        return myBookings;
    };
}
