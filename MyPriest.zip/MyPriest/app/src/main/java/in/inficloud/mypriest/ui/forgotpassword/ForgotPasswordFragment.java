package in.inficloud.mypriest.ui.forgotpassword;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;

import java.util.List;

import in.inficloud.mypriest.R;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserViewModel;

public class ForgotPasswordFragment extends Fragment {

    private TextInputEditText editTextMobile;

    private UserViewModel userViewModel;
    private ForgotPasswordViewModel forgotPasswordViewModel;
    String sMob;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        userViewModel = ViewModelProviders.of(this).get(UserViewModel.class);

        forgotPasswordViewModel =
                ViewModelProviders.of(this).get(ForgotPasswordViewModel.class);
        View root = inflater.inflate(R.layout.fragment_forgotpassword, container, false);


        editTextMobile = root.findViewById(R.id.Forgotmobile);
        Button btnSubmit = root.findViewById(R.id.buttonSend);
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sMob = editTextMobile.getText().toString();
                List<User> priestUser = userViewModel.get(sMob);
                if (priestUser.size() == 0) {
                    Snackbar.make(v, "mobile number does not exist", Snackbar.LENGTH_LONG).show();
                }else{
                    String password = priestUser.get(0).getPassword();
                    String email = priestUser.get(0).getEmail();
                    sendEmail(email,password);
                }
            }
        });
        return root;
    }

    private void sendEmail(String email, String password) {
        //Getting content for email

        String subject = "Your Forgot Password";
        String message = "Password: "+password;

        //Creating SendMail object
        SendMail sm = new SendMail(this.getContext(), email, subject, message);

        //Executing sendmail to send email
        sm.execute();
    }
}
