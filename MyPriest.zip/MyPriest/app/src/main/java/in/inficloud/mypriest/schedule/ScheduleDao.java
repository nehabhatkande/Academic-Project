package in.inficloud.mypriest.schedule;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

import in.inficloud.mypriest.schedule.Schedule;

//import in.inficloud.mypriest.schedule.Schedule;

@Dao
public interface ScheduleDao {
    @Insert
    void insert(Schedule schedule);

    @Update
    void update(Schedule schedule);

    @Delete
    void delete(Schedule schedule);

    @Query("DELETE FROM priest_schedules")
    void  deleteAllSchedules();

    @Query("SELECT * from priest_schedules WHERE priest=:mobile")
    List<Schedule> getSchedules(String mobile);

    @Query("SELECT * from priest_schedules WHERE priest=:mobile AND date=:date")
    List<Schedule> getSchedulesForDay(String mobile,String date);

    @Query("SELECT * FROM priest_schedules")
    LiveData<List<Schedule>> getAllSchedules();
}
