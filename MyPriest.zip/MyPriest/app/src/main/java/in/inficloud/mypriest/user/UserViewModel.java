package in.inficloud.mypriest.user;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class UserViewModel extends AndroidViewModel {

    private UserRepository repository;
    private LiveData<List<User>> allUsers;
    private List<User> users;
    private List<User> priests;

    public UserViewModel(@NonNull Application application) {
        super(application);
        repository = new UserRepository(application);
        allUsers = repository.getAllUsers();
        users = repository.getUsers();
        priests = repository.getPriests();

    }

    public void insert(User user) {
        repository.insert(user);
    }

    public void update(User user) {
        repository.update(user);
    }

    public LiveData<List<User>> getAllUsers() {
        return allUsers;
    }

    public List<User> getReligionPriests(String religion) {
        return repository.getReligionPriests(religion);
    }

    public List<User> get(String mobile) {
        return repository.get(mobile);
    }

    public List<User> getUser(String mobile) {
        return repository.getUser(mobile);
    }

    public List<User> getPriest(String mobile) {
        return repository.getPriest(mobile);
    }

    public List<User> getUsers() {
        return users;
    }

    public List<User> getPriests() {
        return priests;
    }

}