package in.inficloud.mypriest;

import android.content.Intent;

import java.util.Arrays;
import java.util.Calendar;

import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;
import androidx.room.Query;

import com.applandeo.materialcalendarview.CalendarView;
import com.applandeo.materialcalendarview.EventDay;
import com.applandeo.materialcalendarview.listeners.OnDayClickListener;
import com.google.android.material.snackbar.Snackbar;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.util.ArrayList;
import java.util.List;
import java.util.TimeZone;

import in.inficloud.mypriest.booking.BookingViewModel;
import in.inficloud.mypriest.occasion.Occasion;
import in.inficloud.mypriest.occasion.OccasionViewModel;
import in.inficloud.mypriest.schedule.Schedule;
import in.inficloud.mypriest.schedule.ScheduleViewModel;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserViewModel;


public class AddEditBookingActivity extends AppCompatActivity {
    private boolean flag = false;

    private static final String TAG = " ADD";
    private String date;
    public static final String EXTRA_ID =
            "com.example.architectureexample.EXTRA_ID";

    public static final String EXTRA_NAME =
            "com.example.architectureexample.EXTRA_NAME";
    public static final String EXTRA_DATE =
            "com.example.architectureexample.EXTRA_DATE";
    public static final String EXTRA_RELIGION =
            "com.example.architectureexample.EXTRA_RELIGION";
    public static final String EXTRA_PRIEST =
            "com.example.architectureexample.EXTRA_PRIEST";
    public static final String EXTRA_USER =
            "com.example.architectureexample.EXTRA_USER";
    public static final String EXTRA_TIME =
            "com.example.architectureexample.EXTRA_TIME";
    public static final String EXTRA_STATUS =
            "com.example.architectureexample.EXTRA_STATUS";


    private EditText editTextDate;
    //private NumberPicker numberPickerReligion;
    private String sReligion;
    private String sPriest;
    private String sOccasion;
    private String sStatus;
    private BookingViewModel bookingViewModel;
    private UserViewModel userViewModel;
    private OccasionViewModel occViewModel;
    private Calendar selectedDate;
    private ScheduleViewModel scheduleViewModel;
    private String priestMobile;
    private MaterialSpinner spinnerPriest;
    private MaterialSpinner spinnerStatus;
    private TextView priceView;
    List<String> scheduleSpinnerList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_booking);
        Bundle b = getIntent().getExtras();

        sReligion = b.getString("religion");
        Log.d(TAG, "onCreate: "+sReligion);
        userViewModel =
                ViewModelProviders.of(this).get(UserViewModel.class);
        occViewModel =
                ViewModelProviders.of(this).get(OccasionViewModel.class);
        scheduleViewModel = ViewModelProviders.of(this).get(ScheduleViewModel.class);

        //editTextDate = findViewById(R.id.edit_text_date);

        List<User> priests = userViewModel.getReligionPriests(sReligion);
        Log.d(TAG, "onCreate: " + priests.size());
        List<String> priestnames = new ArrayList<>();
        priestnames.add("Select Priest");
        for (User user : priests) {
            priestnames.add(user.getFname() + " " + user.getLname());
        }

        Log.d("REL", "onCreate: " + sReligion);
        List<Occasion> occasions = occViewModel.getMyOccasions(sReligion);
        List<String> sOccasions = new ArrayList<>();
        sOccasions.add("Select Occasion");

        for (Occasion occasion : occasions) {
            sOccasions.add(occasion.getName());
        }

        CalendarView calendarView = (CalendarView) findViewById(R.id.calendarView);

        Calendar min = Calendar.getInstance();
        min.add(Calendar.DAY_OF_MONTH, -1);


        Calendar max = Calendar.getInstance();
        max.add(Calendar.DAY_OF_MONTH, 6);

        calendarView.setMinimumDate(min);
        calendarView.setMaximumDate(max);



        calendarView.setOnDayClickListener(new OnDayClickListener() {
            @Override
            public void onDayClick(EventDay eventDay) {
                scheduleSpinnerList = new ArrayList<>(Arrays.asList("12AM-2AM", "2AM-4AM", "4AM-6AM", "6AM-8AM", "8AM-10AM", "10AM-12PM",
                        "12PM-2PM","2PM-4PM","4PM-6PM","6PM-8PM","8PM-10PM","10PM-12AM"));
                ArrayList needToRemove = new ArrayList();

                flag = true;
                selectedDate = eventDay.getCalendar();
                Log.d(TAG, "onDayClick: "+selectedDate);
                Log.d(TAG, "onDayClick: "+scheduleSpinnerList);

                Toast.makeText(getApplicationContext(),
                        eventDay.getCalendar().getTime().toString() + " "
                                + eventDay.isEnabled(),
                        Toast.LENGTH_SHORT).show();

                date = selectedDate.getTime().toString();
                String[] parts = date.split(" ");
                Log.d(TAG, " : " + parts[0] + " " + parts[1] + " " + parts[2] + " " + parts[5]);
                Log.d(TAG, "saveBooking: " + parts[3]);
                String sdate = parts[1] + ":" + parts[2] + ":" + parts[5] + ":" + parts[0];
                Log.d(TAG, "onDayClick: " + sdate);
                List<Schedule> schedule = scheduleViewModel.getMySchedulesForDay(priestMobile, sdate);
                List<Schedule> myschedule = scheduleViewModel.getMySchedules(priestMobile);
                Log.d(TAG, "onDayClick: " + myschedule.toString());
                if (schedule.size() != 0) {
                    Log.d(TAG, "onDayClick: You need to remove schedule");
                    Log.d(TAG, "onDayClick: " + schedule.get(0).toString());
                    if (schedule.get(0).getTime01() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(0));
                        //scheduleSpinnerList.remove(0);
                    }
                    if (schedule.get(0).getTime02() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(1));
                        //scheduleSpinnerList.remove(1);
                    }
                    if (schedule.get(0).getTime03() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(2));
                        //scheduleSpinnerList.remove(2);
                    }
                    if (schedule.get(0).getTime04() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(3));
                        //scheduleSpinnerList.remove(3);
                    }
                    if (schedule.get(0).getTime05() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(4));
                        //scheduleSpinnerList.remove(4);
                    }
                    if (schedule.get(0).getTime06() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(5));
                        //scheduleSpinnerList.remove(5);
                    }
                    if (schedule.get(0).getTime07() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(6));
                        //scheduleSpinnerList.remove(6);
                    }
                    if (schedule.get(0).getTime08() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(7));
                        //scheduleSpinnerList.remove(7);
                    }
                    if (schedule.get(0).getTime09() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(8));
                        //scheduleSpinnerList.remove(8);
                    }
                    if (schedule.get(0).getTime10() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(9));
                        //scheduleSpinnerList.remove(9);
                    }
                    if (schedule.get(0).getTime11() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(10));
                        //scheduleSpinnerList.remove(10);
                    }
                    if (schedule.get(0).getTime12() == 1) {
                        needToRemove.add(scheduleSpinnerList.get(11));
                        //scheduleSpinnerList.remove(11);
                    }
                    scheduleSpinnerList.removeAll(needToRemove);

                }
                spinnerStatus.setItems(scheduleSpinnerList);
                Log.d(TAG, "onDayClick: " + scheduleSpinnerList);

                Log.d(TAG, "onDayClick: " + priestMobile.toString());
                Log.d(TAG, "onDayClick: " + sdate.toString());
                Log.d(TAG, "onDayClick: " + schedule.toString());


            }

        });





        /*EditText getDate = (EditText) findViewById(R.id.edit_text_date);
        getDate.setOnClickListener(v -> {
            for (java.util.Calendar calendar : calendarView.getSelectedDates()) {
                System.out.println(calendar.getTime().toString());

                Toast.makeText(getApplicationContext(),
                        calendar.getTime().toString(),
                        Toast.LENGTH_SHORT).show();
            }
        });*/


       /* Button getDateButton = (Button) findViewById(R.id.getDateButton);
        getDateButton.setOnClickListener(v -> {
            for (java.util.Calendar calendar : calendarView.getSelectedDates()) {
                System.out.println(calendar.getTime().toString());

                Toast.makeText(getApplicationContext(),
                        calendar.getTime().toString(),
                        Toast.LENGTH_SHORT).show();
            }
        });*/
       priceView = (TextView) findViewById(R.id.rate);
        Log.d("PRI", "onCreate: " + priests.toString());
        final MaterialSpinner spinnerOccasion = findViewById(R.id.occasionName);
        spinnerOccasion.setItems(sOccasions);

        spinnerOccasion.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {

            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                Snackbar.make(view, "Clicked " + item, Snackbar.LENGTH_LONG).show();
                sOccasion = item;
                //Log.d(TAG, "onItemSelected: "+occViewModel.getOccasionPrice(sOccasion));
                priceView.setText("Cost "+"\u20B9"+String.valueOf(occViewModel.getOccasionPrice(sOccasion)));
                //priceView.setText("4000");
            }


        });

        spinnerPriest = findViewById(R.id.priestName);
        spinnerPriest.setItems(priestnames);

        spinnerPriest.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {

            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                Snackbar.make(view, "Clicked " + item, Snackbar.LENGTH_LONG).show();
                sPriest = item;
                Log.d(TAG, "onItemSelected: " + priests.size());
                Log.d(TAG, "onItemSelected: " + position);
                priestMobile = priests.get(position - 1).getMobile();


            }


        });
        spinnerStatus = findViewById(R.id.hour);
        //spinnerStatus.setItems(scheduleSpinnerList);
        spinnerStatus.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener<String>() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, String item) {
                if (flag == true) {
                    scheduleSpinnerList = new ArrayList<>(Arrays.asList("12AM-2AM", "2AM-4AM", "4AM-6AM", "6AM-8AM", "8AM-10AM", "10AM-12PM", "12PM-2PM", "2PM-4PM", "4PM-6PM", "6PM-8PM", "8PM-10PM", "10PM-12PM"
                            ));

                    Log.d(TAG, "onItemSelected: "+selectedDate.toString());

                    selectedDate.add(Calendar.HOUR, scheduleSpinnerList.indexOf(item));
                    date = selectedDate.getTime().toString();
                    Log.d(TAG, "onItemSelected: "+selectedDate.toString());
                    Snackbar.make(view, "Clicked " + item, Snackbar.LENGTH_LONG).show();
                    Log.d(TAG, "onItemSelected: "+item);
                    sStatus = item;
                }
                else{
                    Log.d(TAG, "onItemSelected: "+selectedDate);
                }
            }
        });


        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_close);

        Intent intent = getIntent();

        if (intent.hasExtra(EXTRA_ID)) {
            setTitle("Edit Booking");

            //editTextDate.setText(intent.getStringExtra(EXTRA_DATE));

            //   numberPickerReligion.setValue(intent.getIntExtra(EXTRA_RELIGION, 1));
        } else {
            setTitle("Add Booking");
        }


    }

    private void saveBooking() {

        String name = sOccasion;
        //date = editTextDate.getText().toString();
        String priest = sPriest;

        if (name.trim().isEmpty() || date.trim().isEmpty()) {
            Toast.makeText(this, "Please insert a name and date", Toast.LENGTH_SHORT).show();
            return;
        }


            Intent data = new Intent();
            data.putExtra(EXTRA_NAME, name);
            data.putExtra(EXTRA_PRIEST, priestMobile);


            String[] parts = date.split(" ");
            Log.d(TAG, " : " + parts[0] + " " + parts[1] + " " + parts[2] + " " + parts[5]);
            Log.d(TAG, "saveBooking: " + sStatus);
            data.putExtra(EXTRA_DATE, parts[1] + ":" + parts[2] + ":" + parts[5] + ":" + parts[0]);
            Log.d(TAG, "saveBooking: " + data.getStringExtra(EXTRA_DATE));
            data.putExtra(EXTRA_TIME, parts[3]);
            Log.d(TAG, "saveBooking: " + data.getStringExtra(EXTRA_TIME));

            int id = getIntent().getIntExtra(EXTRA_ID, -1);
            if (id != -1) {
                data.putExtra(EXTRA_ID, id);
            }

            setResult(RESULT_OK, data);
            finish();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.add_booking_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.save_booking:
                if (flag == true) {
                    saveBooking();
                    return true;
                }
                else {
                    Toast.makeText(this, "Please insert a name and date", Toast.LENGTH_SHORT).show();
                }
            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
