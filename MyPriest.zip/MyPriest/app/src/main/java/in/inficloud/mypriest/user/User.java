package in.inficloud.mypriest.user;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.android.gms.maps.model.LatLng;

@Entity(tableName = "priest_users")
public class User {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String fname;
    private String lname;
    private String email;
    private String mobile;
    private String password;
    private String religion;
    private Double latitude;
    private Double longitude;
    private Integer priest;

    public User(String fname, String lname, String email, String mobile, String password, String religion, Integer priest, Double latitude,Double longitude) {
        this.fname = fname;
        this.lname = lname;
        this.email = email;
        this.mobile = mobile;
        this.password = password;
        this.religion = religion;
        this.latitude = latitude;
        this.longitude = longitude;
        this.priest = priest;
    }

    public void setPriest(Integer priest) {
        this.priest = priest;
    }

    public Integer getPriest() {
        return priest;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public String getFname() {
        return fname;
    }

    public String getLname() {
        return lname;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }

    public String getReligion() {
        return religion;
    }

    public Double getLatitude() {
        return latitude;
    }

    public Double getLongitude() {
        return longitude;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setReligion(String religion) {
        this.religion = religion;
    }

    public void setLatitude(Double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude) {
        this.longitude = longitude;
    }
}
