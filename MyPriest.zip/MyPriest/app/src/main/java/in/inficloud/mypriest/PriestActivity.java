package in.inficloud.mypriest;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.common.util.ArrayUtils;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import in.inficloud.mypriest.booking.Booking;
import in.inficloud.mypriest.booking.BookingAdapter;
import in.inficloud.mypriest.booking.BookingViewModel;
import in.inficloud.mypriest.schedule.Schedule;
import in.inficloud.mypriest.schedule.ScheduleViewModel;
import in.inficloud.mypriest.user.User;
import in.inficloud.mypriest.user.UserViewModel;

import static android.content.ContentValues.TAG;

public class PriestActivity extends AppCompatActivity {

    public static final int ADD_ADDRESS_REQUEST = 1;
    public static final int EDIT_NOTE_REQUEST = 2;
    private static final String TAG = "CONFIRM";
    private String sReligion;
    private String sPriest;
    private BookingViewModel bookingViewModel;
    private Booking priestConfirm;
    private UserViewModel userViewModel;
    private ScheduleViewModel scheduleViewModel;
    private UserViewModel userviewmodel;
    private BookingAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_priest);
        Bundle b = getIntent().getExtras();
        sPriest = b.getString("name");
        sReligion = b.getString("religion");
        /*FloatingActionButton buttonAddBooking = findViewById(R.id.button_add_priest);
        buttonAddBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(PriestActivity.this, AddEditBookingActivity.class);
                intent.putExtra("name", sPriest);
                startActivityForResult(intent, ADD_NOTE_REQUEST);
            }
        });*/
        userViewModel =
                ViewModelProviders.of(this).get(UserViewModel .class);
        scheduleViewModel = ViewModelProviders.of(this).get(ScheduleViewModel.class);

        FloatingActionButton buttonCreateProfile = findViewById(R.id.button_priest_profile);
        buttonCreateProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent = new Intent(PriestActivity.this, CustomMarkerClusteringDemoActivity.class);
                /*List<User> priests = userViewModel.getPriests();
                ArrayList<String> names = new ArrayList<>();
                double[] latitudes = new double[priests.size()];
                double[] longitudes = new double[priests.size()];

                for (int i = 0; i<priests.size();i++){
                    names.add(i,priests.get(i).getFname()+ " "+priests.get(i).getLname());
                    latitudes[i] = priests.get(i).getLatitude();
                    longitudes[i] = priests.get(i).getLongitude();


                }
                Log.d(TAG, "onClick: "+names);
                Log.d(TAG, "onClick: "+latitudes);
                Log.d(TAG, "onClick: "+longitudes);
                intent.putExtra("names",names );


                intent.putExtra("latitudes",latitudes);
                intent.putExtra("longitudes",longitudes);
                intent.putExtra("religion", sReligion);*/
                //startActivityForResult(intent, ADD_NOTE_REQUEST);
                startActivityForResult(intent, ADD_ADDRESS_REQUEST);
            }
        });


        RecyclerView recyclerView = findViewById(R.id.recycler_view_priest);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);

        adapter = new BookingAdapter();
        recyclerView.setAdapter(adapter);


        bookingViewModel = ViewModelProviders.of(this).get(BookingViewModel.class);
        bookingViewModel.getPriestBookingsMobile(sPriest).observe(this, new Observer<List<Booking>>() {
            @Override
            public void onChanged(@Nullable List<Booking> bookings) {
                adapter.submitList(bookings);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0,
                ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                bookingViewModel.delete(adapter.getBookingAt(viewHolder.getAdapterPosition()));
                Toast.makeText(PriestActivity.this, "Booking Deleted", Toast.LENGTH_SHORT).show();
            }
        }).attachToRecyclerView(recyclerView);

        adapter.setOnItemClickListener(new BookingAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Booking booking) {
                //userviewmodel= ViewModelProviders.of(getCallingActivity().).get(UserViewModel.class);
                List<User> users = userViewModel.getUser(booking.getUser());

                Log.d(TAG, "onBindViewHolder: "+users);
                Log.d(TAG, "onBindViewHolder: "+booking.getUser());
                Double lat = users.get(0).getLatitude();
                Double lang = users.get(0).getLongitude();
                String fname = users.get(0).getFname();
                String lname = users.get(0).getLname();

                Geocoder geocoder;
                List<Address> addresses = null;
                geocoder = new Geocoder(getApplicationContext());

                Log.d(TAG, "onBindViewHolder: "+lat);
                Log.d(TAG, "onBindViewHolder: "+lang);

                try {
                    if (lat != null && lang != null)
                        addresses = geocoder.getFromLocation(lat, lang, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                } catch (IOException e) {
                    e.printStackTrace();
                }
                String address = " ";
                String city = " ";
                String state = " ";
                String country = " ";
                String postalCode = " ";
                if (lat != null && lang != null) {
                    //address = addresses.get(0).getSubLocality();
                     address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                    city = addresses.get(0).getLocality();
                    state = addresses.get(0).getAdminArea();
                    country = addresses.get(0).getCountryName();
                     postalCode = addresses.get(0).getPostalCode();


                }
                    priestConfirm = booking;
                Intent intent = new Intent(PriestActivity.this, ConfirmRejectActivity.class);
                Log.d(TAG, "onItemClick: "+booking.getId());
                intent.putExtra(AddEditBookingActivity.EXTRA_ID, booking.getId());
                intent.putExtra("name", booking.getName());
                intent.putExtra("religion", booking.getReligion());
                intent.putExtra("date", booking.getDate());
                intent.putExtra("time", booking.getTime());
                intent.putExtra("user", booking.getUser());
                intent.putExtra("fname",fname);
                intent.putExtra("lname",lname);
                intent.putExtra("location",address);
                //intent.putExtra(AddEditBookingActivity.EXTRA_DESCRIPTION, booking.getDescripton());
                startActivityForResult(intent, EDIT_NOTE_REQUEST);
            }



        });
    }




    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_ADDRESS_REQUEST && resultCode == RESULT_OK) {
            Log.d(TAG, "onActivityResult: gotresults");
            Double latitude = data.getDoubleExtra(CustomMarkerClusteringDemoActivity.EXTRA_LATITUDE,0.0);
            Double longitude = data.getDoubleExtra(CustomMarkerClusteringDemoActivity.EXTRA_LANGITUDE,0.0);
            Log.d(TAG, "onActivityResult: "+latitude);
            Log.d(TAG, "onActivityResult: "+longitude);
            List<User> priests = userViewModel.getPriest(sPriest);

            priests.get(0).setLatitude(latitude);
            priests.get(0).setLongitude(longitude);
            userViewModel.update(priests.get(0));

            Toast.makeText(this, "Booking Saved", Toast.LENGTH_SHORT).show();

        } else if (requestCode == EDIT_NOTE_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(ConfirmRejectActivity.EXTRA_ID, -1);
            String name = priestConfirm.getName();
            //String religion = sReligion;
            String religion = priestConfirm.getReligion();
            //String date = data.getStringExtra(AddEditBookingActivity.EXTRA_DATE);
            String date = priestConfirm.getDate();
            //String time = data.getStringExtra(AddEditBookingActivity.EXTRA_TIME);
            String time = priestConfirm.getTime();
            //String user = data.getStringExtra(AddEditBookingActivity.EXTRA_USER);
            String user = priestConfirm.getUser();
            //String priest = data.getStringExtra(AddEditBookingActivity.EXTRA_PRIEST);
            //String priest = sPriest;
            String priest = priestConfirm.getPriest();


            if (id == -1) {
                Toast.makeText(this, "Booking can't be updated ", Toast.LENGTH_SHORT).show();
                return;
            }
            String status = data.getStringExtra(ConfirmRejectActivity.EXTRA_STATUS );
            Log.d(TAG, "onActivityResult: "+status);
            if (status.equals("confirm"))
            {
                Toast.makeText(this,"Booking Confirmed",Toast.LENGTH_SHORT).show();
                Log.d(TAG, "onActivityResult: "+status);

            }
            else if ( status.equals("reject"))
            {
                Toast.makeText(this,"Booking Cancelled",Toast.LENGTH_SHORT).show();
                Log.d(TAG, "onActivityResult: "+status);
                List<Schedule> dayschedule = scheduleViewModel.getMySchedulesForDay(sPriest,date);
                //Schedule dayschedule = schedules.get(0);
                Log.d(TAG, "onActivityResult: "+sPriest);
                Log.d(TAG, "onActivityResult: "+date);
                Log.d(TAG, "onActivityResult: "+dayschedule);
                Log.d(TAG, "onActivityResult: "+time);
                String [] parts = time.split( ":");

                if (dayschedule.size() != 0) {
                    Schedule schedule = dayschedule.get(0);
                    List<Integer> stime = new ArrayList<>();
                    Log.d(TAG, "onActivityResult: " + stime.size());
                    stime.add(0, schedule.getTime01());
                    stime.add(1, schedule.getTime02());
                    stime.add(2, schedule.getTime03());
                    stime.add(3, schedule.getTime04());
                    stime.add(4, schedule.getTime05());
                    stime.add(5, schedule.getTime06());
                    stime.add(6, schedule.getTime07());
                    stime.add(7, schedule.getTime08());
                    stime.add(8, schedule.getTime09());
                    stime.add(9, schedule.getTime10());
                    stime.add(10, schedule.getTime11());
                    stime.add(11, schedule.getTime12());

                    stime.set(Integer.parseInt(parts[0]), 0);
                    Log.d(TAG, "onActivityResult: "+parts[0]);

                    schedule.setTime01(stime.get(0));
                    schedule.setTime02(stime.get(1));
                    schedule.setTime03(stime.get(2));
                    schedule.setTime04(stime.get(3));
                    schedule.setTime05(stime.get(4));
                    schedule.setTime06(stime.get(5));
                    schedule.setTime07(stime.get(6));
                    schedule.setTime08(stime.get(7));
                    schedule.setTime09(stime.get(8));
                    schedule.setTime10(stime.get(9));
                    schedule.setTime11(stime.get(10));
                    schedule.setTime12(stime.get(11));

                    scheduleViewModel.update(schedule);
                }

                }
            //String name = data.getStringExtra(AddEditBookingActivity.EXTRA_NAME);
            //String status = sReligion;
            //String sStatus = data.getStringExtra(AddEditBookingActivity.EXTRA_STATUS);
            //String status = priestConfirm.getStatus();

           // Booking booking = new Booking(name, religion, date,time, priest, user,status);
            //booking.setId(id);
            priestConfirm.setStatus(status);

            bookingViewModel.update(priestConfirm);
            adapter.notifyDataSetChanged();

            Toast.makeText(this, "Booking updated", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(this, "Booking Not Saved", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu_bookings, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete_all_bookings:
                bookingViewModel.deleteAllBookings();
                Toast.makeText(this, "All bookings deleted", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }

}
