package in.inficloud.mypriest.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.util.List;

import in.inficloud.mypriest.AdminActivity;
import in.inficloud.mypriest.PriestActivity;
import in.inficloud.mypriest.R;
import in.inficloud.mypriest.UserActivity;
import in.inficloud.mypriest.ui.register.RegisterViewModel;
import in.inficloud.mypriest.user.User;

                        public class LoginFragment extends Fragment {

                            private LoginViewModel loginViewModel;
                            private TextInputEditText editTextFirstName;
                            private TextInputEditText editTextLastName;

                            private TextInputEditText editTextEmail;
                            private TextInputEditText editTextMobile;
                            private TextInputEditText editTextPassword;
                            private TextInputEditText editTextRepeatPassword;
                            private CheckBox checkBoxPriest;
                            private MaterialButton btnLogin;
                            String sFirstName, sLastName, sEmail, sMobile, sPassword, sRepeatPassword, sReligion;
                            Boolean bPriest;



                            public View onCreateView(@NonNull LayoutInflater inflater,
                                                     ViewGroup container, Bundle savedInstanceState) {
                                loginViewModel =
                                        ViewModelProviders.of(this).get(LoginViewModel.class);

                                View root = inflater.inflate(R.layout.fragment_login, container, false);

                                editTextMobile = root.findViewById(R.id.mobile);
                                editTextPassword = root.findViewById(R.id.password);
                                btnLogin = root.findViewById(R.id.login);

                                btnLogin.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        sMobile = editTextMobile.getText().toString();
                                        sPassword = editTextPassword.getText().toString();
                                        if (sMobile.equals("7406131872") && sPassword.equals("MyPriestAdmin@03")) {
                                            Intent i = new Intent(getActivity(), AdminActivity.class);
        startActivity(i);
        }
        List<User> users = loginViewModel.auth(sMobile,sPassword);
        if (users.size() == 0) {
        Snackbar.make(v, "Login Failed", Snackbar.LENGTH_LONG).show();
        } else {
        Snackbar.make(v, "Login Successful "+users.get(0).getFname()+" "+users.get(0).getLname(), Snackbar.LENGTH_LONG).show();
        if (users.get(0).getPriest() == 0) {
        Intent i = new Intent(getActivity(), UserActivity.class);
        i.putExtra("name", users.get(0).getMobile());
        i.putExtra("lat",users.get(0).getLatitude());
        i.putExtra("lan",users.get(0).getLongitude());
        i.putExtra("religion", users.get(0).getReligion());
        startActivity(i);
        } else {
        Intent i = new Intent(getActivity(), PriestActivity.class);
        i.putExtra("name", users.get(0).getMobile());
        i.putExtra("religion", users.get(0).getReligion());
        startActivity(i);
        }
        }
        }
        });

        return root;
        }

        }
